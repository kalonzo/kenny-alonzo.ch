﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Net.Mail;

namespace EtudiantsVDLGestion_Web
{
    // REMARQUE : vous pouvez utiliser la commande Renommer du menu Refactoriser pour changer le nom de classe "EtudiantsVDLGestionService" à la fois dans le code, le fichier svc et le fichier de configuration.
    public class EtudiantsVDLGestionService : IEtudiantsVDLGestionService
    {


        //service permettant d'envoyer un mail lors de trois echecs d'inscription
        public void sendMail(string vdl, string user)
        {



            string fromEmail = "kenny.alonzo@lausanne.ch";//This field will contain the FROM email 
            string ToEmail = "kenny.alonzo@lausanne.ch";//This field will contain destination email             
            string body = "Hello"; //This field will contain the body of the email 
            string subject = "Test"; //This field will contain the subject 


            SmtpClient MyMail = new SmtpClient("https://owa.lausanne.ch/owa/");//exchange or smtp server goes here. 
            //MyMail.DeliveryMethod = SmtpDeliveryMethod.Network;
            //MyMail.UseDefaultCredentials = true;
            //MyMail.ClientCertificates = "";
            // MyMail.Send(fromEmail, ToEmail, subject, body);




            /* MailMessage mail = new MailMessage();
             SmtpClient SmtpServer = new SmtpClient("LSNXCH40.lausanne.ch");

             mail.From = new MailAddress("kenny.alonzo@lausanne.ch");
             mail.To.Add("kenny.alonzo@lausanne.ch");
             mail.Subject = "This is for testing SMTP mail from GMAIL";
             mail.Body = "Le compte " + vdl + " à été bloqué par l'utilisateurs" + user;

            // SmtpServer.Port = 587;
             SmtpServer.UseDefaultCredentials = true;
             SmtpServer.Credentials = new System.Net.NetworkCredential();
             //SmtpServer.EnableSsl = true;

             SmtpServer.Send(mail);
             */

        }


        //permet d'identifié l'utilisateur lors du login
        public Boolean getAuthentif(string userSOI, string userFormatteurEtudiantsVDL, string pwd)
        {

            Boolean verif = false;

            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();

            var authentif = from e1 in dc.formatteurEtudiantsVDL
                            where e1.userFormatteurEtudiantsVDL.Equals(userFormatteurEtudiantsVDL)
                            where e1.userSOI.Equals(userSOI)
                            select new { e1.userFormatteurEtudiantsVDL, e1.userSOI };

            string pwdDB = string.Empty;
            var test = dc.decryptPWDAdmin(pwd);

            foreach (var row in test)
            {
                if (row.userFormatteurEtudiantsVDL != "N")
                {
                    foreach (var row2 in authentif)
                    {
                        if (row2.userSOI.Equals(userSOI))
                        {
                            if (row2.userFormatteurEtudiantsVDL.Equals(userFormatteurEtudiantsVDL))
                            {
                                verif = true;
                            }
                        }
                    }
                }
            }

            return verif;
        }


        //methode permettant de controler ci l'etudiant c'est deja loguer dans la journées
        public List<string> WhoisAuthentif(string userSOI, string userFormatteurEtudiantsVDL)
        {

            //Boolean verif = false;
            List<string> lst = new List<string>();

            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();
            //string userVDL = "";
            int id = -1;
            // int idTest = -1;
            //string nom_test = string.Empty;
            string auth = string.Empty;
            string bann = string.Empty;
            //  int userVDL_id = -1;
            // int id_role = -1;
            string metier = string.Empty;
            int id_metier = -1;
            // int id_userVDL = -1;
            string forName = string.Empty;

            if (userFormatteurEtudiantsVDL == null)
            {
                userFormatteurEtudiantsVDL = "";

                var authentif = from e1 in dc.formatteurEtudiantsVDL
                                where e1.userSOI.Equals(userSOI.ToUpper())
                                select new { e1.userFormatteurEtudiantsVDL, e1.auth, e1.bann, e1.id_formatteurEtudiantsVDL, e1.nom_formatteur, e1.prenom_formatteur };

                foreach (var rown in authentif) { userFormatteurEtudiantsVDL = rown.userFormatteurEtudiantsVDL; id = rown.id_formatteurEtudiantsVDL; auth = rown.auth; bann = rown.bann; forName = rown.nom_formatteur + " " + rown.prenom_formatteur; }
            }
            else
            {

                var authentif = from e1 in dc.formatteurEtudiantsVDL
                                where e1.userSOI.Equals(userSOI.ToUpper())
                                where e1.userFormatteurEtudiantsVDL.Equals(userFormatteurEtudiantsVDL)
                                select new { e1.userFormatteurEtudiantsVDL, e1.auth, e1.bann, e1.id_formatteurEtudiantsVDL, e1.nom_formatteur, e1.prenom_formatteur };

                foreach (var rown in authentif) { userFormatteurEtudiantsVDL = rown.userFormatteurEtudiantsVDL; id = rown.id_formatteurEtudiantsVDL; auth = rown.auth; bann = rown.bann; forName = rown.nom_formatteur + " " + rown.prenom_formatteur; }
            }

            //permet de retrouver l'utilisateur 


            if (!userFormatteurEtudiantsVDL.Equals(""))
            {


                lst.Add(id.ToString());
                lst.Add("0");
                lst.Add("0");
                lst.Add(userSOI);
                lst.Add(userFormatteurEtudiantsVDL);
                lst.Add(auth);
                lst.Add(bann);
                lst.Add("1");
                lst.Add("1");
                lst.Add("1");
                lst.Add("1");
                lst.Add("1");
                lst.Add(forName);

            }

            return lst;

        }


        //authentifi l'utilisateur lors de la prochaine connexions
        public bool auth(string userFormatteurEtudiantsVDL)
        {
            bool auth = false;
            if (userFormatteurEtudiantsVDL != "")
            {
                EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();
                var authentif = (from c in dc.formatteurEtudiantsVDL
                                 where c.userFormatteurEtudiantsVDL.Equals(userFormatteurEtudiantsVDL)
                                 select c).First();

                authentif.auth = "Y";
                dc.SubmitChanges();
                auth = true;

            }


            return auth;

        }


        //Dé logue lutilisateurs du site
        public Boolean delo(int id_formatteurEtudiantsVDL)
        {

            Boolean quit = true;
            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();
            var authentif = (from c in dc.formatteurEtudiantsVDL
                             where c.id_formatteurEtudiantsVDL == id_formatteurEtudiantsVDL
                             select c).First();

            if (authentif != null)
            {
                authentif.auth = "N";
                dc.SubmitChanges();
            }
            else
            {
                quit = false;
            }



            return quit;

        }

        public string getUserVDL(int id_formatteurEtudiantsVDL)
        {

            string str = string.Empty;

            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();
            var authentif = from user in dc.formatteurEtudiantsVDL
                            where user.id_formatteurEtudiantsVDL == id_formatteurEtudiantsVDL
                            select new { user.userFormatteurEtudiantsVDL };


            foreach (var row in authentif)
            {
                str = row.userFormatteurEtudiantsVDL;
            }

            return str;
        }



        //Construction de la GUI
        public List<roleEtudiantsVDL> getRoles()
        {
            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();

            var Groupe = from cust in dc.roleEtudiantsVDL.AsEnumerable()
                         select cust;

            return Groupe.ToList();
        }



        public List<actions> getActions(int id_role)
        {

            //List<string[]> plop = new List<string[]>();

            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();

            var Etudiants = from ax in dc.actions.AsEnumerable()
                            where ax.id_roleEtudiantsVDL == id_role
                            select ax;

            return Etudiants.ToList();
        }



        //Affichage des etudiants
        public List<string[]> getEtudiants(int id_groupe)
        {

            List<string[]> plop = new List<string[]>();


            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();


            if (id_groupe == -1)
            {

                //selections de tout les etudiants
                var etudiants = from et in dc.etudiants
                                from typ in dc.type_etudiants
                                from met in dc.metiers
                                from gr in dc.groupes
                                join us in dc.userVDL on et.id_etudiant equals us.id_etudiant
                                where met.id_metier == gr.id_metier
                                where et.id_type_etudiant == typ.id_type_etudiant
                                where et.id_groupe == gr.id_groupe
                                select new { et.id_etudiant, et.nom_etu, et.prenom_etu, et.age_etu, typ.id_type_etudiant, typ.nom_typEtu, gr.id_groupe, gr.nom_gro, et.connecte, us.userVDL1, met.id_metier, met.nom_metier };

                foreach (var row in etudiants)
                {
                    plop.Add(new string[] { row.id_etudiant.ToString(), row.nom_etu, row.prenom_etu, row.age_etu, row.id_type_etudiant.ToString(), row.nom_typEtu, row.id_groupe.ToString(), row.nom_gro, row.connecte, row.userVDL1, row.id_metier.ToString(), row.nom_metier });
                }
            }
            else
            {
                var etudiants = from et in dc.etudiants
                                from typ in dc.type_etudiants
                                from met in dc.metiers
                                from gr in dc.groupes
                                join us in dc.userVDL on et.id_etudiant equals us.id_etudiant
                                where met.id_metier == gr.id_metier
                                where et.id_type_etudiant == typ.id_type_etudiant
                                where et.id_groupe == gr.id_groupe
                                where gr.id_groupe == id_groupe
                                select new { et.id_etudiant, et.nom_etu, et.prenom_etu, et.age_etu, typ.id_type_etudiant, typ.nom_typEtu, gr.id_groupe, gr.nom_gro, et.connecte, us.userVDL1, met.id_metier, met.nom_metier };

                foreach (var row in etudiants)
                {
                    plop.Add(new string[] { row.id_etudiant.ToString(), row.nom_etu, row.prenom_etu, row.age_etu, row.id_type_etudiant.ToString(), row.nom_typEtu, row.id_groupe.ToString(), row.nom_gro, row.connecte, row.userVDL1, row.id_metier.ToString(), row.nom_metier });
                }

            }

            return plop;
        }


        //permet de populer la combo box de metier 
        public List<string[]> getMetier()
        {
            int metOrph = 6;
            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();

            List<string[]> plop = new List<string[]>();


            var etudiants = (from met in dc.metiers select new { met.id_metier, met.nom_metier }).ToList();

            foreach (var row in etudiants)
            {
                if (row.id_metier == metOrph)
                {
                }
                else
                {
                    plop.Add(new string[] { row.id_metier.ToString(), row.nom_metier });
                }

            }




            return plop;
        }

        //permet de populer la combo box de groupe 
        public List<string[]> getGroupe(int id_metier, bool orph = false)
        {
            int groOrph = 24;
            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();

            List<string[]> plop = new List<string[]>();

            if (orph)
            {
                var etudiants = (from gro in dc.groupes
                                 where gro.id_metier == id_metier
                                 select new { gro.id_groupe, gro.nom_gro }).ToList();

                var etudiants2 = (from gro in dc.groupes
                                  where gro.id_metier == 6
                                  select new { gro.id_groupe, gro.nom_gro }).ToList();



                foreach (var row in etudiants.Union(etudiants2))
                {
                    if (row.id_groupe == groOrph)
                    {

                    }
                    else
                    {
                        plop.Add(new string[] { row.id_groupe.ToString(), row.nom_gro });
                    }

                }

            }
            else
            {

                var etudiants = (from gro in dc.groupes
                                 where gro.id_metier == id_metier
                                 select new { gro.id_groupe, gro.nom_gro }).ToList();


                foreach (var row in etudiants)
                {
                    if (row.id_groupe == groOrph)
                    {

                    }
                    else
                    {
                        plop.Add(new string[] { row.id_groupe.ToString(), row.nom_gro });
                    }

                }
            }


            return plop;
        }


        public int InsertetudiantsUser(int id_etudiants, string nom_etu, string prenom_etu, string age_etu, string nom_typ, int id_gro, string userVDL1, string pwd)
        {
            int verif = 0;
            int typ_etudiants = -1;


            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();


            //insertion de nouveau etudiants

            var type_etu = (from et in dc.type_etudiants
                            where et.nom_typEtu.Equals(nom_typ)
                            select new { et.id_type_etudiant }).Distinct();


            foreach (var puc in type_etu)
            {
                typ_etudiants = puc.id_type_etudiant;
            }


            if (typ_etudiants == -1)
            {

                //creation du datacontexte pour l'insertion du nouveau type d'etudiants
                EtudiantsVDLGestionDataClassesDataContext dcTyp = new EtudiantsVDLGestionDataClassesDataContext();

                //le type d'etudiants n'existe pas et doit etre crée
                type_etudiants typ = new type_etudiants
                {

                    descn_typEtu = "Nouveau type d'etudiants",
                    nom_typEtu = nom_typ
                };

                dc.type_etudiants.InsertOnSubmit(typ);
                dc.SubmitChanges();

                typ_etudiants = typ.id_type_etudiant;

            }


            if (id_etudiants == -1)
            {
                //insertion d'un nouvel utilisateur dans la base
                //inscription de l'etudiants
                etudiants etu = new etudiants
                {
                    nom_etu = nom_etu,
                    prenom_etu = prenom_etu,
                    age_etu = age_etu,
                    id_type_etudiant = typ_etudiants,
                    id_groupe = id_gro,
                    connecte = "N"

                };

                // Add the new object to the Orders collection.
                dc.etudiants.InsertOnSubmit(etu);
                dc.SubmitChanges();

                EtudiantsVDLGestionDataClassesDataContext dc2 = new EtudiantsVDLGestionDataClassesDataContext();

                //verifi ci l'utilisateur  existe déja
                var userVDL = from us in dc2.userVDL
                              where us.userVDL1.ToUpper().Equals(userVDL1.ToUpper())
                              select us;

                if (userVDL.Count() != 0)
                {
                    //retourne 1 ci l'utilisateur existe déja
                    verif = 1;
                }
                else
                {
                    //inscription de l'utilisateur
                    dc2.InsertUser(etu.id_etudiant, "LOCAL", userVDL1, pwd);
                    dc2.SubmitChanges();
                    //retourne 1 ci l'utilisateur existe déja
                    // verif = 1;
                }
            }
            else
            {
                if (typ_etudiants == -1)
                {

                    //creation du datacontexte pour l'insertion du nouveau type d'etudiants
                    EtudiantsVDLGestionDataClassesDataContext dcTyp = new EtudiantsVDLGestionDataClassesDataContext();

                    //le type d'etudiants n'existe pas et doit etre crée
                    type_etudiants typ = new type_etudiants
                    {

                        descn_typEtu = "Nouveau type d'etudiants",
                        nom_typEtu = nom_typ
                    };

                    dc.type_etudiants.InsertOnSubmit(typ);
                    dc.SubmitChanges();

                    typ_etudiants = typ.id_type_etudiant;

                }


                EtudiantsVDLGestionDataClassesDataContext dcTyp2 = new EtudiantsVDLGestionDataClassesDataContext();
                //selections de l'etudiants
                var etu = (from et in dcTyp2.etudiants
                           where et.id_etudiant == id_etudiants
                           select et).First();

                //modifications des champs incriminé

                etu.nom_etu = nom_etu;
                etu.prenom_etu = prenom_etu;
                etu.age_etu = age_etu;
                etu.id_type_etudiant = typ_etudiants;
                etu.id_groupe = id_gro;
                etu.connecte = "N";

                dcTyp2.SubmitChanges();


                if (pwd != "")
                {
                    //suppresion de l'utilisateur de la base
                    EtudiantsVDLGestionDataClassesDataContext dcUser = new EtudiantsVDLGestionDataClassesDataContext();

                    var user = from et in dcUser.etudiants
                               join us in dcUser.userVDL on et.id_etudiant equals us.id_etudiant
                               where et.id_etudiant == id_etudiants
                               select us;

                    foreach (var row in user)
                    {
                        dcUser.userVDL.DeleteOnSubmit(row);

                    }

                    dcUser.SubmitChanges();

                    EtudiantsVDLGestionDataClassesDataContext dcu2 = new EtudiantsVDLGestionDataClassesDataContext();
                    //verifi ci l'utilisateur  existe déja
                    var userVDL = from us in dcu2.userVDL
                                  where us.userVDL1.ToUpper().Equals(userVDL1.ToUpper())
                                  select us;

                    if (userVDL.Count() != 0)
                    {
                        //retourne 1 ci l'utilisateur existe déja
                        verif = 1;
                    }
                    else
                    {
                        //inscription de l'utilisateur
                        dcu2.InsertUser(etu.id_etudiant, "LOCAL", userVDL1, pwd);
                        dcu2.SubmitChanges();
                        //retourne 1 ci l'utilisateur existe déja
                        // verif = 1;
                    }

                }

            }
            return verif;

        }


        public bool DelEtudiant(int id_etudiant)
        {
            bool verif = true;
            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();

            int id_droit_test = new int();



            //EtudiantsVDLGestionDataClassesDataContext dc2 = new EtudiantsVDLGestionDataClassesDataContext();
            //verifi ci l'etudiants à un test en cours a cause de la sépendance drois_test
            var droit = from dr in dc.droits_tests
                        from te in dc.tests
                        from et in dc.etudiants
                        where dr.id_test == te.id_test
                        where dr.id_etudiant == et.id_etudiant
                        where et.id_etudiant == id_etudiant
                        select dr;

            foreach (var row in droit)
            {
                dc.droits_tests.DeleteOnSubmit(row);

            }

            dc.SubmitChanges();


            var deleteOrderDetails =
            from et in dc.etudiants
            where et.id_etudiant == id_etudiant
            select et;


            foreach (var detail in deleteOrderDetails)
            {
                dc.etudiants.DeleteOnSubmit(detail);
            }

            dc.SubmitChanges();

            return verif;

        }


        public List<string[]> getModule(int id_metier, int id_groupe, bool orph = false)
        {
            int modOrph = 18;
            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();

            List<string[]> plop = new List<string[]>();


            var mod = from met in dc.metiers
                      from gro in dc.groupes
                      from modu in dc.modules
                      from pro in dc.programmes
                      where met.id_metier == gro.id_metier
                      where pro.id_groupe == gro.id_groupe
                      where pro.id_module == modu.id_module
                      where gro.id_groupe == id_groupe
                      where met.id_metier == id_metier
                      select new { pro.id_programme, gro.id_groupe, modu.id_module, modu.nom_mod };
            if (orph)
            {

                var mod2 = from met in dc.metiers
                           from gro in dc.groupes
                           from modu in dc.modules
                           from pro in dc.programmes
                           where met.id_metier == gro.id_metier
                           where pro.id_groupe == gro.id_groupe
                           where pro.id_module == modu.id_module
                           where gro.id_groupe == 24
                           where met.id_metier == 6
                           select new { pro.id_programme, gro.id_groupe, modu.id_module, modu.nom_mod };

                foreach (var row in mod2.Union(mod))
                {
                    if (row.id_module == modOrph)
                    {
                    }
                    else
                    {
                        plop.Add(new string[] { row.id_programme.ToString(), row.id_groupe.ToString(), row.id_module.ToString(), row.nom_mod });
                    }
                }


            }
            else
            {
                foreach (var row in mod)
                {
                    if (row.id_module == modOrph)
                    {
                    }
                    else
                    {
                        plop.Add(new string[] { row.id_programme.ToString(), row.id_groupe.ToString(), row.id_module.ToString(), row.nom_mod });
                    }
                }
            }
            return plop;
        }


        //ajout de metiers
        public bool InsertMetier(string nom_met, int id_met)
        {
            bool verif = true;


            if (id_met == -1)
            {
                EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();
                metiers met = new metiers
                {
                    nom_metier = nom_met,
                    descn_met = "Inserer par l'application"
                };

                // Add the new object to the Orders collection.
                dc.metiers.InsertOnSubmit(met);
                dc.SubmitChanges();
            }
            else
            {
                EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();
                var upMet = from met in dc.metiers
                            where met.id_metier == id_met
                            select met;

                foreach (var row in upMet)
                {

                    row.nom_metier = nom_met;
                }
                dc.SubmitChanges();
            }

            return verif;

        }

        //Suppresion de metiers en cascade 
        //
        public bool delMetier(int id_met)
        {
            bool verif = true;
            //Controle ci il reste des etudiants dans le metier donner en id
            //ci un des asminisrateur é les droit accorder sur le metiers ces droits sont revoqué
            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();
            // EtudiantsVDLGestionDataClassesDataContext dcFVDL = new EtudiantsVDLGestionDataClassesDataContext();
            var FVDL = from adm in dc.formatteurEtudiantsVDL
                       where adm.id_metier == id_met
                       select adm;
            foreach (var row in FVDL)
            {
                row.id_metier = 6;
            }
            dc.SubmitChanges();


            ///////////////////////////////////////////////////////////////////////
            //Controle ci il reste des etudiants dans le metier donner en id
            //déplace les etudiants dans le groupes sans metiers
            // EtudiantsVDLGestionDataClassesDataContext dcEtu = new EtudiantsVDLGestionDataClassesDataContext();
            var etuQ = from etu in dc.etudiants
                       from gro in dc.groupes
                       from met in dc.metiers
                       where gro.id_metier == met.id_metier
                       where gro.id_groupe == etu.id_groupe
                       where met.id_metier == id_met
                       select etu;
            foreach (var row in etuQ)
            {
                row.id_groupe = 24;
            }
            dc.SubmitChanges();


            //deplacaement des groupe dans un metier sans nom ni spécifications
            ///////////////////////////////////////////////////////////////////////
            //Traitemewnt des groupes 
            //EtudiantsVDLGestionDataClassesDataContext dcGro = new EtudiantsVDLGestionDataClassesDataContext();
            var etuGro = from gro in dc.groupes
                         from met in dc.metiers
                         where gro.id_metier == met.id_metier
                         where met.id_metier == id_met
                         select gro;
            foreach (var row in etuGro)
            {
                row.id_metier = 6;
            }
            dc.SubmitChanges();

            //Supression d'un metier e de sa stucture



            var deleteMetiers = from met in dc.metiers
                                where met.id_metier == id_met
                                select met;

            foreach (var detail in deleteMetiers)
            {
                dc.metiers.DeleteOnSubmit(detail);
            }

            dc.SubmitChanges();

            return verif;
        }


        //ajout de groupes
        public bool InsertGroupe(int id_met, string nom_gro, int id_gro)
        {
            bool verif = true;

            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();

            if (id_gro == -1)
            {
                groupes gro = new groupes
                {

                    id_metier = id_met,
                    nom_gro = nom_gro,
                    resp_gro = "inserer par l'applications",
                    descn_gro = "inserer par l'applications"
                };

                // Add the new object to the Orders collection.
                dc.groupes.InsertOnSubmit(gro);
                dc.SubmitChanges();
            }
            else
            {

                var upGro = from gro in dc.groupes
                            where gro.id_groupe == id_gro
                            select gro;

                foreach (var row in upGro)
                {
                    row.nom_gro = nom_gro;
                }
                dc.SubmitChanges();

            }

            return verif;

        }

        //Suppresion de groupes
        public bool delGroupe(int id_gro)
        {
            bool verif = true;
            int id_groMet = 24;


            ///////////////////////////////////////////////////////////////////////
            //Controle ci il reste des etudiants dans le metier donner en id
            //déplace les etudiants dans le groupes sans metiers
            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();
            var etuQ = from etu in dc.etudiants
                       from gro in dc.groupes
                       from met in dc.metiers
                       where gro.id_metier == met.id_metier
                       where gro.id_groupe == etu.id_groupe
                       where gro.id_groupe == id_gro
                       select etu;
            foreach (var row in etuQ)
            {
                row.id_groupe = id_groMet;
            }
            dc.SubmitChanges();


            //modifie la liaison des données entre le goupr et les modules
            //deplace les module de groupe///////////////////////////////////////////////////////////////////
            //EtudiantsVDLGestionDataClassesDataContext dcMod = new EtudiantsVDLGestionDataClassesDataContext();

            var modUP = from gro in dc.groupes
                        from pro in dc.programmes
                        from mod in dc.modules
                        where gro.id_groupe == pro.id_groupe
                        where mod.id_module == pro.id_module
                        where gro.id_groupe == id_gro
                        select pro;

            //24 represente le groupe sans metier 
            //18 represewnt le module sans groupe permet d'acceuilir tout les questions
            foreach (var row in modUP)
            {
                row.id_groupe = id_groMet;
                //row.id_module = 18;
            }
            dc.SubmitChanges();

            //efface tous groupe
            // EtudiantsVDLGestionDataClassesDataContext dc2 = new EtudiantsVDLGestionDataClassesDataContext();

            var deleteGro = from gro in dc.groupes
                            where gro.id_groupe == id_gro
                            select gro;


            foreach (var detail in deleteGro)
            {
                dc.groupes.DeleteOnSubmit(detail);
            }

            dc.SubmitChanges();

            return verif;

        }


        public List<string[]> getQes(int id_mod)
        {

            List<string[]> lst_Qest = new List<string[]>();
            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();

            var qest = from qes in dc.questions
                       where qes.id_module == id_mod
                       select new { qes.id_question, qes.id_module, qes.intitule_que, qes.nombre_point_que, qes.multiQes };

            foreach (var row in qest)
            {

                lst_Qest.Add(new string[] { row.id_question.ToString(), row.id_module.ToString(), row.intitule_que, row.nombre_point_que, row.multiQes });
            }


            return lst_Qest;

        }

        //reconstitution du questinnaire
        public List<string[]> getQest(int id_test, int id_mod)
        {

            List<string[]> lstQest = new List<string[]>();

            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();


            if (id_test != -1)
            {


                var qests = from tes in dc.tests
                            from protes in dc.programme_tests
                            from qest in dc.questionnaires
                            from qes in dc.questions
                            from rep in dc.reponses
                            where tes.id_test == protes.id_test
                            where protes.id_question == qes.id_question
                            where qes.id_question == qest.id_question
                            where rep.id_reponse == qest.id_reponse
                            where tes.id_test == id_test
                            select new { qes.id_question, rep.id_reponse, qes.intitule_que, rep.intitule_rep, qest.juste, qes.nombre_point_que };


                foreach (var row in qests)
                {
                    lstQest.Add(new string[] { row.id_question.ToString(), row.id_reponse.ToString(), row.intitule_que, row.intitule_rep, row.juste, row.nombre_point_que });
                }

            }
            else
            {

                var qests = from qest in dc.questionnaires
                            from qes in dc.questions
                            from rep in dc.reponses
                            from mod in dc.modules
                            where mod.id_module == qes.id_module
                            where qes.id_question == qest.id_question
                            where rep.id_reponse == qest.id_reponse
                            where mod.id_module == id_mod
                            select new { qes.id_question, rep.id_reponse, qes.intitule_que, rep.intitule_rep, qest.juste, qes.nombre_point_que };

                foreach (var row in qests)
                {
                    lstQest.Add(new string[] { row.id_question.ToString(), row.id_reponse.ToString(), row.intitule_que, row.intitule_rep, row.juste, row.nombre_point_que });
                }


            }

            return lstQest;

        }

        //Efface la questions
        public bool delQest(int id_qes)
        {
            bool verif = false;

            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();
            //Suppression de la questions dans tous les test ou elle est 

            var delpro = from prote in dc.programme_tests
                         from tes in dc.tests
                         from qest in dc.questions
                         where prote.id_test == tes.id_test
                         where qest.id_question == prote.id_question
                         where qest.id_question == id_qes
                         select prote;
            if (delpro.Count() != 0)
            {
                //procede à l'effacemnet
                foreach (var row in delpro)
                {
                    dc.programme_tests.DeleteOnSubmit(row);
                }
                dc.SubmitChanges();

            }

            //Supprimer les questionnaire de la questions
            var qesti = from qest in dc.questionnaires
                        from rep in dc.reponses
                        from qes in dc.questions
                        where rep.id_reponse == qest.id_reponse
                        where qes.id_question == qest.id_question
                        where qes.id_question == id_qes
                        select qest;

            if (qesti.Count() != 0)
            {
                foreach (var row in qesti)
                {
                    dc.questionnaires.DeleteOnSubmit(row);
                }
                dc.SubmitChanges();
            }

            //efface la questions
            var qestions = from qes in dc.questions
                           where qes.id_question == id_qes
                           select qes;

            foreach (var row in qestions)
            {
                dc.questions.DeleteOnSubmit(row);
            }
            dc.SubmitChanges();

            return verif;

        }

        //Requonstitution du questionnaire selon la qestion
        public List<string[]> getRep(int id_qes)
        {

            List<string[]> lst_rep = new List<string[]>();
            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();
            var rept = from rep in dc.reponses
                       from qest in dc.questionnaires
                       from qes in dc.questions
                       where rep.id_reponse == qest.id_reponse
                       where qes.id_question == qest.id_question
                       where qes.id_question == id_qes
                       select new { rep.id_reponse, rep.intitule_rep, qest.juste };

            foreach (var row in rept)
            {
                lst_rep.Add(new string[] { row.id_reponse.ToString(), row.intitule_rep, row.juste });
            }

            return lst_rep;

        }



        //afichage des réponses de tout le module
        public List<string[]> getReps(int id_mod)
        {

            List<string[]> lst_rep = new List<string[]>();
            int id_qesMod = 9;
            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();
            var rept = from rep in dc.reponses
                       from qest in dc.questionnaires
                       from qes in dc.questions
                       from mod in dc.modules
                       where mod.id_module == qes.id_module
                       where rep.id_reponse == qest.id_reponse
                       where qes.id_question == qest.id_question
                       where mod.id_module == id_mod
                       select new { rep.id_reponse, rep.intitule_rep, qest.juste };

            var rept2 = from rep in dc.reponses
                        from qest in dc.questionnaires
                        from qes in dc.questions
                        where rep.id_reponse == qest.id_reponse
                        where qest.id_question == qes.id_question
                        where qes.id_question == id_qesMod
                        select new { rep.id_reponse, rep.intitule_rep, qest.juste };

            foreach (var row in rept.Union(rept2))
            {
                lst_rep.Add(new string[] { row.id_reponse.ToString(), row.intitule_rep, row.juste });
            }

            return lst_rep;

        }

        //insertion ou mise a jour du rformulaire 
        public bool InsertQest(int id_mod, int id_qes, string nom_qes, string points, string multiQes, List<string[]> lstrep)
        {

            bool verif = false;
            int id_finalqes = new int();

            //traitement des questions 
            //nouvele questions a inserer
            if (id_qes == -1)
            {
                EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();

                //insertion de la questions
                questions qes = new questions
                {

                    id_module = id_mod,
                    intitule_que = nom_qes,
                    nombre_point_que = points,
                    multiQes = multiQes,
                    date_inscription_que = "Today"
                };
                // Add the new object to the Orders collection.
                dc.questions.InsertOnSubmit(qes);
                dc.SubmitChanges();
                id_finalqes = qes.id_question;
            }
            else
            {
                id_finalqes = id_qes;
                EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();

                var qest = from qes in dc.questions
                           where qes.id_question == id_qes
                           select qes;

                foreach (var row in qest)
                {
                    row.intitule_que = nom_qes;
                    row.nombre_point_que = points;
                    row.multiQes = multiQes;
                    row.date_inscription_que = "Today";
                }
                dc.SubmitChanges();

            }


            //traitement des reponse
            int i = 0;
            foreach (var row in lstrep)
            {
                //la reponse doit etre crée
                if (row[0].ToString().Equals(""))
                {
                    int id_rep = new int();

                    EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();
                    //insertion de la questions
                    reponses rep = new reponses
                    {
                        intitule_rep = row[1].ToString(),
                        date_inscription_rep = "Today"
                    };
                    // Add the new object to the Orders collection.
                    // row[i][0] = rep.id_reponse.ToString();
                    id_rep = rep.id_reponse;
                    dc.reponses.InsertOnSubmit(rep);
                    dc.SubmitChanges();

                    //insertion du questionnaire
                    questionnaires qest = new questionnaires
                    {
                        id_question = id_finalqes,
                        id_reponse = rep.id_reponse,
                        juste = row[2]
                    };
                    dc.questionnaires.InsertOnSubmit(qest);
                    dc.SubmitChanges();
                }
                else
                {
                    EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();
                    //la reponse doit etre modifier réinserer
                    //controle du questionnaire
                    var rept = from rep in dc.reponses
                               where rep.id_reponse == Int32.Parse(row[0].ToString())
                               select rep;


                    //Modifications de la réponse
                    foreach (var row21 in rept)
                    {
                        row21.intitule_rep = row[1];
                        row21.date_inscription_rep = "Today";
                    }
                    dc.SubmitChanges();

                    //verifi ci un questionnaire existe deja pour cette questions
                    var qesti = from qest in dc.questionnaires
                                from rep in dc.reponses
                                from qes in dc.questions
                                where qest.id_question == qes.id_question
                                where qest.id_reponse == rep.id_reponse
                                where qes.id_question == id_finalqes
                                where rep.id_reponse == Int32.Parse(row[0].ToString())
                                select qest;

                    if (qesti.Count() != 0)
                    {
                        foreach (var rowqest in qesti)
                        {
                            rowqest.id_question = id_finalqes;
                            rowqest.id_reponse = Int32.Parse(row[0].ToString());
                            rowqest.juste = row[2];
                        }
                        dc.SubmitChanges();
                    }
                    else
                    {
                        EtudiantsVDLGestionDataClassesDataContext dc5 = new EtudiantsVDLGestionDataClassesDataContext();
                        //insertion du questionnaire
                        questionnaires qest = new questionnaires
                        {
                            id_question = id_finalqes,
                            id_reponse = Int32.Parse(row[0].ToString()),
                            juste = row[2]
                        };
                        dc5.questionnaires.InsertOnSubmit(qest);
                        dc5.SubmitChanges();
                    }


                }

                i++;
            }



            return verif;

        }


        public int InsertQestToTest(int id_test, int id_qes, int id_mod, string nom_gro, string nom_mod)
        {
            //int verif = true;


            //insertion du questionnaire

            //le test n'existe pas et doit etre crée
            if (id_test == -1)
            {
                EtudiantsVDLGestionDataClassesDataContext dcount = new EtudiantsVDLGestionDataClassesDataContext();


                var nbTE = (from tes in dcount.tests
                            from prote in dcount.programme_tests
                            from qes in dcount.questions
                            from mod in dcount.modules
                            where tes.id_test == prote.id_test
                            where qes.id_question == prote.id_question
                            where qes.id_module == mod.id_module
                            where mod.id_module == id_mod
                            select tes).Distinct().Count();


                EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();
                tests test = new tests
                {
                    nom_tes = "Test " + nom_gro + " " + nom_mod + " " + (nbTE + 1).ToString(),
                    date_inscription_tes = "Today",
                    temps_accorde_tes = "30",
                    nombre_points_tes = "0"
                };
                dc.tests.InsertOnSubmit(test);
                dc.SubmitChanges();
                id_test = test.id_test;

            }

            EtudiantsVDLGestionDataClassesDataContext dc2 = new EtudiantsVDLGestionDataClassesDataContext();
            programme_tests pros = new programme_tests
            {
                id_question = id_qes,
                id_test = id_test,
                nom_proTes = "Inserer par l'application"
            };
            dc2.programme_tests.InsertOnSubmit(pros);
            dc2.SubmitChanges();

            return id_test;
        }


        //mise a jour du test
        public bool SubmitTest(int id_test, string nom_tes, string temps_acc, string nbPoints)
        {
            bool verif = false;

            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();

            var UPTe = (from tes in dc.tests
                        where tes.id_test == id_test
                        select tes).Distinct();


            foreach (var row in UPTe)
            {
                row.nom_tes = nom_tes;
                row.date_inscription_tes = "dfd";
                row.temps_accorde_tes = temps_acc;
                row.nombre_points_tes = nbPoints;
            }

            dc.SubmitChanges();

            return verif;
        }



        //ajout de réponse auy comptes goutes pour la GUI
        public List<string[]> getRepToAdd(int id_rep)
        {

            List<string[]> lst_rep = new List<string[]>();

            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();

            var rept = from rep in dc.reponses
                       from qest in dc.questionnaires
                       from mod in dc.modules
                       from qes in dc.questions
                       where qest.id_question == qes.id_question
                       where rep.id_reponse == qest.id_reponse
                       where mod.id_module == qes.id_module
                       where rep.id_reponse == id_rep
                       select new { rep.id_reponse, rep.intitule_rep, qest.juste };


            foreach (var row in rept)
            {

                lst_rep.Add(new string[] { row.id_reponse.ToString(), row.intitule_rep, row.juste });
            }

            return lst_rep;

        }

        //hote la réponse du questionnaire
        public bool delrepToQest(int id_qes, int id_rep)
        {
            bool verif = false;
            int id_qesMod = 9;
            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();


            var qest2 = from qest in dc.questionnaires
                        where qest.id_question == id_qes
                        where qest.id_reponse == id_rep
                        select qest;


            foreach (var row in qest2)
            {
                //row.id_question = id_qesMod;
                dc.questionnaires.DeleteOnSubmit(row);
            }
            dc.SubmitChanges();


            return verif;
        }


        //supprime la questions de la base
        public bool delRep(int id_rep)
        {
            bool verif = false;

            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();

            //Efface la liason de la réponse a d'eventuelle questionnaire
            var delrep = from qesu in dc.questionnaires
                         from qes in dc.questions
                         from rep in dc.reponses
                         where qesu.id_question == qes.id_question
                         where qesu.id_reponse == rep.id_reponse
                         where rep.id_reponse == id_rep
                         select qesu;


            //ci le questionnaire exise le suprime 
            if (delrep.Count() != 0)
            {
                foreach (var row in delrep)
                {
                    dc.questionnaires.DeleteOnSubmit(row);
                }
                dc.SubmitChanges();

                //Efface la réponse de la base
                var repo = from rep in dc.reponses
                           where rep.id_reponse == id_rep
                           select rep;

                foreach (var row in repo)
                {
                    dc.reponses.DeleteOnSubmit(row);
                }
                dc.SubmitChanges();

            }

            return verif;
        }

        //ajout de module
        public bool InsertMod(int id_gro, string nom_mod, int id_mod)
        {
            bool verif = true;

            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();

            if (id_mod == -1)
            {
                //insertion du nouveau module dans la base
                modules mod = new modules
                {
                    nom_mod = nom_mod,
                    responsable_mod = "inserer par l'applications"

                };

                // Add the new object to the Orders collection.
                dc.modules.InsertOnSubmit(mod);
                dc.SubmitChanges();


                //insertion de la dépendance au groupe
                EtudiantsVDLGestionDataClassesDataContext dc2 = new EtudiantsVDLGestionDataClassesDataContext();

                //insertion du nouveau module dans la base
                programmes pro = new programmes
                {
                    id_groupe = id_gro,
                    id_module = mod.id_module
                };

                // Add the new object to the Orders collection.
                dc2.programmes.InsertOnSubmit(pro);
                dc2.SubmitChanges();

            }
            else
            {

                var upMod = from mod in dc.modules
                            where mod.id_module == id_mod
                            select mod;

                foreach (var row in upMod)
                {
                    row.nom_mod = nom_mod;
                }

                dc.SubmitChanges();

            }

            return verif;

        }

        //Suppresion des modules 54
        public bool delMod(int id_mod)
        {
            bool verif = true;

            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();
            //((EtudiantsVDLGestionDataClassesDataContext dcpro = new EtudiantsVDLGestionDataClassesDataContext();

            var Qpro = from pro in dc.programmes
                       from mod in dc.modules
                       from gro in dc.groupes
                       where pro.id_groupe == gro.id_groupe
                       where pro.id_module == mod.id_module
                       where mod.id_module == id_mod
                       select pro;
            foreach (var row in Qpro)
            {
                dc.programmes.DeleteOnSubmit(row);
            }
            dc.SubmitChanges();



            //  EtudiantsVDLGestionDataClassesDataContext dcQe = new EtudiantsVDLGestionDataClassesDataContext();
            //deplacement des questions dans un module qui n'apartien a aucun groupe
            var qes = from gro in dc.groupes
                      from que in dc.questions
                      from modu in dc.modules
                      from pro in dc.programmes
                      where pro.id_groupe == gro.id_groupe
                      where pro.id_module == modu.id_module
                      where que.id_module == modu.id_module
                      where modu.id_module == id_mod
                      select que;
            foreach (var row in qes)
            {
                row.id_module = 18;
            }
            dc.SubmitChanges();


            //efface toute les questions des test


            // EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();
            var deleteMod = from mod in dc.modules
                            where mod.id_module == id_mod
                            select mod;


            foreach (var detail in deleteMod)
            {
                dc.modules.DeleteOnSubmit(detail);
            }

            dc.SubmitChanges();

            return verif;
        }


        //enleve le questionnaire du test
        public bool delQestFromTest(int id_tes, int id_qes)
        {
            bool verif = false;
            EtudiantsVDLGestionDataClassesDataContext dcQe = new EtudiantsVDLGestionDataClassesDataContext();


            var delQest = from protes in dcQe.programme_tests
                          where protes.id_question == id_qes
                          where protes.id_test == id_tes
                          select protes;

            foreach (var row in delQest)
            {

                dcQe.programme_tests.DeleteOnSubmit(row);
            }

            dcQe.SubmitChanges();


            return verif;
        }


        //Effacer le test et son questionnaire
        public bool DelTest(int id_tes)
        {
            bool verif = false;
            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();

            //efface les droits questionnaire
            var potes = from pro in dc.programme_tests
                        where pro.id_test == id_tes
                        select pro;

            foreach (var row in potes)
            {
                dc.programme_tests.DeleteOnSubmit(row);
            }

            dc.SubmitChanges();

            //efface les droits accorder pour le test
            var droits = from dro in dc.droits_tests
                         where dro.id_test == id_tes
                         select dro;

            foreach (var row in droits)
            {
                dc.droits_tests.DeleteOnSubmit(row);
            }

            dc.SubmitChanges();

            //Suppression du test 
            var test = from te in dc.tests
                       where te.id_test == id_tes
                       select te;

            foreach (var row in test)
            {
                dc.tests.DeleteOnSubmit(row);
            }

            dc.SubmitChanges();

            return verif;

        }



        public List<string[]> getTest(int id_mod)
        {

            List<string[]> plop = new List<string[]>();

            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();

            var test = (from tes in dc.tests
                        from prote in dc.programme_tests
                        from qes in dc.questions
                        from mod in dc.modules
                        where tes.id_test == prote.id_test
                        where qes.id_question == prote.id_question
                        where qes.id_module == mod.id_module
                        where mod.id_module == id_mod
                        select new { tes.id_test, tes.nom_tes, tes.temps_accorde_tes }).Distinct();

            foreach (var row in test)
            {
                plop.Add(new string[] { row.id_test.ToString(), row.nom_tes, row.temps_accorde_tes });
            }
            return plop;
        }


        public List<string[]> getEtuByTest(int id_test, int id_gro)
        {

            List<string[]> plop = new List<string[]>();

            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();
            string id_droits_test = "-1";
            string droitE = "N";

            var etud = (from etu in dc.etudiants
                        from typ in dc.type_etudiants
                        from modu in dc.modules
                        from pro in dc.programmes
                        from gro in dc.groupes
                        join us in dc.userVDL on etu.id_etudiant equals us.id_etudiant
                        where etu.id_type_etudiant == typ.id_type_etudiant
                        where modu.id_module == pro.id_module
                        where gro.id_groupe == pro.id_groupe
                        where etu.id_groupe == gro.id_groupe
                        where gro.id_groupe == id_gro
                        select new { etu.id_etudiant, etu.nom_etu, etu.prenom_etu, typ.nom_typEtu, us.userVDL1, id_droits_test, droitE }).Distinct();
            //etu.id_etudiant, etu.nom_etu , etu.prenom_etu, typ.nom_typEtu,us.userVDL, '-1' id_droits_test, 'N' droitE

            var etutest = (from typ in dc.type_etudiants
                           from dro in dc.droits_tests
                           from tes in dc.tests
                           from gro in dc.groupes
                           from pro in dc.programmes
                           from etu in dc.etudiants
                           join us in dc.userVDL on etu.id_etudiant equals us.id_etudiant
                           where etu.id_type_etudiant == typ.id_type_etudiant
                           where dro.id_etudiant == etu.id_etudiant
                           where tes.id_test == dro.id_test
                           where tes.id_test == id_test
                           orderby dro.droitE descending
                           orderby etu.id_etudiant ascending
                           select new { etu.id_etudiant, etu.nom_etu, etu.prenom_etu, typ.nom_typEtu, us.userVDL1, dro.id_droits_test, dro.droitE }).Distinct();


            int i = 0;
            int currentEtu = new int();
            foreach (var row in etud)
            {
                currentEtu = row.id_etudiant;
                plop.Add(new string[] { row.id_etudiant.ToString(), row.nom_etu, row.prenom_etu, row.nom_typEtu, row.userVDL1, row.id_droits_test, row.droitE });
                foreach (var row2 in etutest)
                {
                    if (row2.id_etudiant == currentEtu)
                    {
                        plop.RemoveAt(i);
                        plop.Add(new string[] { row2.id_etudiant.ToString(), row2.nom_etu, row2.prenom_etu, row2.nom_typEtu, row2.userVDL1, row2.id_droits_test.ToString(), row2.droitE });
                    }
                }
                i++;
            }



            return plop;

        }


        public bool InsertDroits(int id_test, int id_droits, int id_etudiants, bool droitest)
        {
            bool verif = false;
            string dr = string.Empty;
            //string droitest = string.Empty;
            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();

            //verifi ci les droits doivent etre attribuer ou hoter
            //Switch droits test ci le test est accorder le test n'es plus accorder
            if (droitest)
            {
                dr = "N";
            }
            else
            {
                dr = "Y";
            }


            //ci le droits et deja activé
            if (id_droits != -1)
            {

                //verifie que le droits du test et deja été accorder
                var dro = from drot in dc.droits_tests
                          from etu in dc.etudiants
                          from tes in dc.tests
                          where drot.id_etudiant == etu.id_etudiant
                          where drot.id_test == tes.id_test
                          where drot.id_etudiant == id_etudiants
                          where tes.id_test == id_test
                          select drot;

                //Modifications du droits
                foreach (var row in dro)
                {
                    row.droitE = dr;
                }
                dc.SubmitChanges();

            }
            else
            {
                //creation du droits pour le test en cours

                //insertion du nouveau module dans la base
                droits_tests pro = new droits_tests
                {
                    id_etudiant = id_etudiants,
                    id_test = id_test,
                    droitE = "Y",
                    teFini = "N",
                    date_planification = "today"

                };

                // Add the new object to the Orders collection.
                dc.droits_tests.InsertOnSubmit(pro);
                dc.SubmitChanges();

            }

            return verif;
        }

        public List<string[]> getTestByEtudiants(int id_etudiants) {
            List<string[]> plop = new List<string[]>();
            EtudiantsVDLGestionDataClassesDataContext dc = new EtudiantsVDLGestionDataClassesDataContext();

            var query = (from et in dc.etudiants
                        from por in dc.portfolios
                        from res in dc.resultats
                        from tes in dc.tests
                        where et.id_etudiant == por.id_etudiant
                        where por.id_resultat == res.id_resultat
                        where tes.id_test == res.id_test
                        where et.id_etudiant == id_etudiants
                        select new { tes.id_test, tes.nom_tes, tes.temps_accorde_tes }).Distinct();

            foreach (var row in query)
            {
                plop.Add(new string[] { row.id_test.ToString(), row.nom_tes, row.temps_accorde_tes });
            }


            return plop;
        }

        List<actions> IEtudiantsVDLGestionService.getActions(int id_role)
        {
            throw new NotImplementedException();
        }
    }
}
