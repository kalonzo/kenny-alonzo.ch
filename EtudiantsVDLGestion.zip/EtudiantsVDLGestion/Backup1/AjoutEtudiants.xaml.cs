﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace EtudiantsVDLGestion
{
    public partial class AjoutEtudiants : ChildWindow
    {
        public AjoutEtudiants()
        {

            //Population des combobox

            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.getMetierCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getMetierCompletedEventArgs>(affiche_metier);
            client.getMetierAsync();


            InitializeComponent();
        }


        /////variable 
        int id_metier = new int();
        int id_groupe = new int();
        List<work.metiers> lst_metier = new List<work.metiers>();


        public void affiche_metier(object sender, EtudiantsVDLGestion.ServiceReference1.getMetierCompletedEventArgs e)
        {

            lst_metier = new List<work.metiers>();
            id_metier = -1;


            foreach (var row in e.Result)
            {
                lst_metier.Add(new work.metiers { id_metier = row[0].ToString(), nom_metier = row[1] });

            }

            lst_metier.Add(new work.metiers { id_metier = "-1", nom_metier = "All" });

            cbxMet.ItemsSource = lst_metier;
            cbxMet.DisplayMemberPath = "nom_metier";
            cbxMet.SelectionChanged += new SelectionChangedEventHandler(cb_SelectionChanged);

            cbxMet2.ItemsSource = lst_metier;
            cbxMet2.DisplayMemberPath = "nom_metier";
            cbxMet2.SelectionChanged += new SelectionChangedEventHandler(cbGro_SelectionChangedAdd);


            //affichage de tous lesetudiants de la base

            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.getEtudiantsCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getEtudiantsCompletedEventArgs>(affiche_etudiants);
            client.getEtudiantsAsync(-1);


        }

        work.metiers selectedCarMet = new work.metiers();

        //action declencher lors du changement de metier
        void cb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            selectedCarMet = (work.metiers)cbxMet.SelectedItem;

            id_metier = Int32.Parse(selectedCarMet.id_metier);


            //Population des combobox groupe

            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.getGroupeCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getGroupeCompletedEventArgs>(affiche_groupe);
            client.getGroupeAsync(id_metier, false);

            // System.Windows.MessageBox.Show(selectedCar.nom_metier);


        }


        public List<work.Groupes> lst_groupe = new List<work.Groupes>();

        public void affiche_groupe(object sender, EtudiantsVDLGestion.ServiceReference1.getGroupeCompletedEventArgs e)
        {


            lst_groupe = new List<work.Groupes>();
            id_metier = -1;


            // System.Windows.MessageBox.Show(e.Result[0].ToString());
            foreach (var row in e.Result)
            {
                lst_groupe.Add(new work.Groupes { id_groupe = row[0].ToString(), nom_groupe = row[1] });
            }


            cbxGro.ItemsSource = lst_groupe;
            cbxGro.DisplayMemberPath = "nom_groupe";
            cbxGro.SelectionChanged += new SelectionChangedEventHandler(cbGro_SelectionChanged);

            cbxGro2.ItemsSource = lst_groupe;
            cbxGro2.DisplayMemberPath = "nom_groupe";


        }

        public work.Groupes selectedCar = new work.Groupes();

        //action declencher lors du changement de groupe
        void cbGro_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedCar = (work.Groupes)cbxGro.SelectedItem;
            // System.Windows.MessageBox.Show(selectedCar.nom_groupe);

            if (selectedCar != null)
            {
                id_groupe = Int32.Parse(selectedCar.id_groupe);

                //Population des combobox groupe
                EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                client.getGroupeCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getGroupeCompletedEventArgs>(affiche_groupeby);
                client.getGroupeAsync(id_groupe, false);
            }
            else
            {
                EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                client.getEtudiantsCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getEtudiantsCompletedEventArgs>(affiche_etudiants);
                client.getEtudiantsAsync(-1);

            }

        }

        public void affiche_groupeby(object sender, EtudiantsVDLGestion.ServiceReference1.getGroupeCompletedEventArgs e)
        {

            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.getEtudiantsCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getEtudiantsCompletedEventArgs>(affiche_etudiants);
            client.getEtudiantsAsync(id_groupe);

        }

        public void affiche_etudiants(object sender, EtudiantsVDLGestion.ServiceReference1.getEtudiantsCompletedEventArgs e)
        {

            List<work.Etudiants> et = new List<work.Etudiants>();


            foreach (var row in e.Result)
            {
                et.Add(new work.Etudiants { id_etudiants = Int32.Parse(row[0]), nom = row[1], prenom = row[2], age = row[3], id_typ = Int32.Parse(row[4]), nomTyp = row[5], id_groupe = Int32.Parse(row[6]), nomGroupe = row[7], connecte = row[8], nomUtilisateur = row[9], id_met = Int32.Parse(row[10]), nom_met = row[11] });
            }


            //System.Windows.MessageBox.Show(e.Result.ToList().ToString());
            // dgetudiants.DataContext = e.Result;
            dgetudiants.ItemsSource = et;

        }


        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }


        work.Etudiants selectedCarEt = new work.Etudiants();



        //actions declencher lors du click sur lîmage ajout
        //modifi l'etudiants si sélectionné / ajout un nouveau etudiants

        public bool addEtudiant = false;

        private void imgCoche_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

            imgCoche.Source = new System.Windows.Media.Imaging.BitmapImage(new Uri("/EtudiantsVDLGestion;component/image/cocheVerteClick.png", UriKind.Relative));


            if (!addEtudiant)
            {


                //ordone les combobox
                if (cbxMet.SelectedIndex != -1)
                {
                    cbxMet2.SelectedIndex = cbxMet.SelectedIndex;
                    cbxGro2.SelectedIndex = cbxGro.SelectedIndex;
                }

                ajoutEtudiant.Visibility = Visibility.Visible;
                addEtudiant = true;

            }
            else
            {

                txtNom.Text = "";
                txtPrenom.Text = "";
                txtAge.Text = "";
                txtUser.Text = "";
                txtTypEtu.Text = "";
                txtPWD.Password = "";
                txtPWD2.Password = "";

                ajoutEtudiant.Visibility = Visibility.Collapsed;
                addEtudiant = false;

            }


        }


        public work.metiers selectedCarMet2 = new work.metiers();
        void cbGro_SelectionChangedAdd(object sender, SelectionChangedEventArgs e)
        {

            if (cbxMet2.SelectedIndex != -1)
            {
                selectedCarMet2 = (work.metiers)cbxMet2.SelectedItem;
                // System.Windows.MessageBox.Show(selectedCar.nom_groupe);

                //Population des combobox groupe
                EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                client.getGroupeCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getGroupeCompletedEventArgs>(affiche_groupeAdd);
                client.getGroupeAsync(Int32.Parse(selectedCarMet2.id_metier), false);

            }
        }

        public List<work.Groupes> lst_groupeAdd = new List<work.Groupes>();


        public void affiche_groupeAdd(object sender, EtudiantsVDLGestion.ServiceReference1.getGroupeCompletedEventArgs e)
        {

            lst_groupeAdd = new List<work.Groupes>();

            // System.Windows.MessageBox.Show(e.Result[0].ToString());
            foreach (var row in e.Result)
            {
                lst_groupeAdd.Add(new work.Groupes { id_groupe = row[0].ToString(), nom_groupe = row[1] });
            }


            cbxGro2.ItemsSource = lst_groupeAdd;
            cbxGro2.DisplayMemberPath = "nom_groupe";
            //cbxGro2.SelectionChanged += new SelectionChangedEventHandler(cbGro_SelectionChanged); 

        }




        private void imgCoche_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            imgCoche.Source = new System.Windows.Media.Imaging.BitmapImage(new Uri("/EtudiantsVDLGestion;component/image/cocheVerte.jpg", UriKind.Relative));
            // System.Windows.MessageBox.Show("click");

        }


        //permet de retenir le groupe et metier passé en parametre
        public work.Groupes selectedCarGRO2 = new work.Groupes();
        private void addEtudiantDB_Click(object sender, RoutedEventArgs e)
        {

            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            //reprewnt les parametre passer en arguments
            selectedCarGRO2 = (work.Groupes)cbxGro2.SelectedItem;


            if (checkInsert())
            {
                //controle que le mot de pass soit correctement saisie 
                if (txtPWD.Password.Equals(txtPWD2.Password))
                {
                    //Permet d'inserer 
                    client.InsertetudiantsUserCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.InsertetudiantsUserCompletedEventArgs>(insert_etu);
                    client.InsertetudiantsUserAsync(id_etudiants, txtNom.Text, txtPrenom.Text, txtAge.Text, txtTypEtu.Text, Int32.Parse(selectedCarGRO2.id_groupe), txtUser.Text, txtPWD.Password.ToString());
                }
                else
                {
                    //mot de pass non confirmer
                    System.Windows.MessageBox.Show("mot de PasswordBox non confirmer");

                }
            }
            else
            {
                bob = new composant.ConfirmPopUP();
                bob.lbprompt.Content = "Veuillez remplir tous les champs\navant de proceder à l'insertion d'un nouvel etudiant";
                bob.CancelButton.IsEnabled = false;
                bob.Show();
            }

        }

        //ecouteur de l'insertion d'etudiants
        public void insert_etu(object sender, EtudiantsVDLGestion.ServiceReference1.InsertetudiantsUserCompletedEventArgs e)
        {


            if (e.Result == 1)
            {
                bob = new composant.ConfirmPopUP();
                bob.CancelButton.Visibility = Visibility.Visible;
                bob.lbprompt.Content = "L'utilisateurs " + txtUser.Text + " et deja assigné";
                bob.Show();
                txtNom.Text = "";
                txtPrenom.Text = "";
                txtAge.Text = "";
                txtUser.Text = "";
                txtTypEtu.Text = "";
                txtPWD.Password = "";
                txtPWD2.Password = "";

                cbxMet2.SelectedIndex = -1;
                ajoutEtudiant.Visibility = Visibility.Collapsed;

                cbxGro2.SelectedIndex = -1;

            }
            else
            {
                txtNom.Text = "";
                txtPrenom.Text = "";
                txtAge.Text = "";
                txtUser.Text = "";
                txtTypEtu.Text = "";
                txtPWD.Password = "";
                txtPWD2.Password = "";

                cbxMet2.SelectedIndex = -1;
                ajoutEtudiant.Visibility = Visibility.Collapsed;

                cbxGro2.SelectedIndex = -1;
                EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client2 = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                client2.getEtudiantsCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getEtudiantsCompletedEventArgs>(affiche_etudiants);
                client2.getEtudiantsAsync(-1);
            }
        }




        //Suppresion de l'etudiants selectiner dans la datagrid
        private void Image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {


        }

        composant.ConfirmPopUP bob = new composant.ConfirmPopUP();
        public work.Etudiants selectedEtu = new work.Etudiants();
        //action declencher lors du clic sur le bouton effacer
        private void Image_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {

            selectedEtu = (work.Etudiants)dgetudiants.SelectedItem;

            if (selectedEtu != null)
            {
                bob = new composant.ConfirmPopUP();
                bob.lbprompt.Content = "Voulez-vous vraiment supprimer " + selectedEtu.nom + " " + selectedEtu.prenom + "\ntous ses résultats seront supprimés";
                bob.Closed += new EventHandler(bob_Closed);
                bob.Show();
            }

        }

        public void bob_Closed(object sender, EventArgs e)
        {

            if (bob.lbverif.Content.Equals("true"))
            {
                if (selectedEtu != null)
                {
                    EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                    client.DelEtudiantCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.DelEtudiantCompletedEventArgs>(del_etu);
                    client.DelEtudiantAsync(selectedEtu.id_etudiants);
                }
            }

        }




        public void del_etu(object sender, EtudiantsVDLGestion.ServiceReference1.DelEtudiantCompletedEventArgs e)
        {

            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client2 = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client2.getEtudiantsCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getEtudiantsCompletedEventArgs>(affiche_etudiants);
            client2.getEtudiantsAsync(-1);

            //System.Windows.MessageBox.Show("suppresion de" + selectedEtu.id_etudiants.ToString());
        }


        int id_etudiants = -1;
        //actions déclenché lors de l'edition d'un etudiants
        public bool edit = false;
        private void Image_MouseLeftButtonUp_1(object sender, MouseButtonEventArgs e)
        {

            //Verifie ci la fenetre est deja ouverte
            if (!edit)
            {
                selectedCarEt = (work.Etudiants)dgetudiants.SelectedItem;


                //stockl'id de l'etudiants sélectionnée dans le fatagrid
                id_etudiants = selectedCarEt.id_etudiants;
                ajoutEtudiant.Visibility = Visibility.Visible;

                //reprise des attribut pour

                txtNom.Text = selectedCarEt.nom;
                txtPrenom.Text = selectedCarEt.prenom;
                txtAge.Text = selectedCarEt.age;
                txtUser.Text = selectedCarEt.nomUtilisateur;
                txtTypEtu.Text = selectedCarEt.nomTyp;

                cbxMet2.ItemsSource = lst_metier;
                cbxMet2.DisplayMemberPath = "nom_metier";
                cbxMet2.SelectedItem = selectedCarEt.nom_met;
                // cbxMet2.SelectionChanged += new SelectionChangedEventHandler(cbGro_SelectionChangedAdd);

                //cbxGro2.ItemsSource = lst_groupe;
                // cbxGro2.DisplayMemberPath = "nom_groupe";
                cbxGro2.SelectedItem = selectedCarEt.nomGroupe;

                edit = true;
            }
            else
            {

                txtNom.Text = "";
                txtPrenom.Text = "";
                txtAge.Text = "";
                txtUser.Text = "";
                txtTypEtu.Text = "";
                txtPWD.Password = "";
                txtPWD2.Password = "";
                cbxMet2.SelectedIndex = -1;
                cbxGro2.SelectedIndex = -1;
                ajoutEtudiant.Visibility = Visibility.Collapsed;
                edit = false;

            }

        }


            //Déclaration d'une fenetre popup pour les message d'indications

            //fonction de verification des champs
            public bool checkInsert(){
            bool verif = true;

                //Controle ci les champs sont vide
            if (((txtAge.Text.Replace(" ", "") == "") || (txtNom.Text.Replace(" ", "") == "") || (txtPrenom.Text.Replace(" ", "") == "") || (txtTypEtu.Text.Replace(" ", "") == "") || (txtUser.Text.Replace(" ", "") == "") || (cbxMet2.SelectedIndex == -1) || (cbxGro2.SelectedIndex == -1)))
            {
                verif = false;
            }


            return verif;
            
            }
        
    }
}

