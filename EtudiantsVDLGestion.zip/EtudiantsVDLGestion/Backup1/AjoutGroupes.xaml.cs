﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace EtudiantsVDLGestion
{
    public partial class AjoutGroupes : ChildWindow
    {
        public AjoutGroupes()
        {

            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.getMetierCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getMetierCompletedEventArgs>(affiche_metier);
            client.getMetierAsync();

            InitializeComponent();
        }


        //population de la combobox des metier
        /////variable 
        int id_metier = new int();
        int id_groupe = new int();
        List<work.metiers> lst_metier = new List<work.metiers>();

        public void affiche_metier(object sender, EtudiantsVDLGestion.ServiceReference1.getMetierCompletedEventArgs e)
        {

            lst_metier = new List<work.metiers>();
            List<string> lst_metier2 = new List<string>();
            id_metier = -1;

            foreach (var row in e.Result)
            {
                lst_metier.Add(new work.metiers { id_metier = row[0].ToString(), nom_metier = row[1] });
            }



            txtMet.DataContext = lst_metier;
            //  txtMet.SelectionChanged += new SelectionChangedEventHandler(txt_SelectionChanged);
            autoCompleteMet.ItemsSource = lst_metier;
            autoCompleteMet.SelectionChanged += new SelectionChangedEventHandler(cb_SelectionChanged);
        }


        //Afficher les metier dans la premiee lisbox
        work.metiers selectedCarMet = new work.metiers();
        //action declencher lors du changement de metier
        void cb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedCarMet = (work.metiers)autoCompleteMet.SelectedItem;

            if (selectedCarMet != null)
            {
                id_metier = Int32.Parse(selectedCarMet.id_metier);

                //Population des combobox groupe
                EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                client.getGroupeCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getGroupeCompletedEventArgs>(affiche_groupe);
                client.getGroupeAsync(id_metier, false);
            }
        }

        //affiche les groupe  contenu dans le metier x
        public List<work.Groupes> lst_groupe = new List<work.Groupes>();
        public void affiche_groupe(object sender, EtudiantsVDLGestion.ServiceReference1.getGroupeCompletedEventArgs e)
        {
            lst_groupe = new List<work.Groupes>();

            // System.Windows.MessageBox.Show(e.Result[0].ToString());
            foreach (var row in e.Result)
            {
                lst_groupe.Add(new work.Groupes { id_groupe = row[0].ToString(), nom_groupe = row[1] });
            }

            autoCompleteGro.ItemsSource = lst_groupe;
            autoCompleteGro.SelectionChanged += new SelectionChangedEventHandler(cb_SelectionChangedGro);

            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.getGroupeCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getGroupeCompletedEventArgs>(affiche_groupeOrph);
            client.getGroupeAsync(id_metier, true);
        }

        public void affiche_groupeOrph(object sender, EtudiantsVDLGestion.ServiceReference1.getGroupeCompletedEventArgs e)
        {
            lst_groupe = new List<work.Groupes>();

            // System.Windows.MessageBox.Show(e.Result[0].ToString());
            foreach (var row in e.Result)
            {
                lst_groupe.Add(new work.Groupes { id_groupe = row[0].ToString(), nom_groupe = row[1] });
            }

            txtGro.DataContext = lst_groupe;
        }


        //action declencher lors du changement de groupe
        //affiche la liste des module pour ce gfoupe
        public work.Groupes selectedCar = new work.Groupes();

        void cb_SelectionChangedGro(object sender, SelectionChangedEventArgs e)
        {
            selectedCar = (work.Groupes)autoCompleteGro.SelectedItem;

            if (selectedCar != null)
            {
                if (selectedCarMet != null)
                {
                    selectedCar = (work.Groupes)autoCompleteGro.SelectedItem;

                    EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                    client.getModuleCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getModuleCompletedEventArgs>(affiche_mod);
                    client.getModuleAsync(Int32.Parse(selectedCarMet.id_metier), Int32.Parse(selectedCar.id_groupe), false);
                }
            }
            else
            {
                EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                client.getGroupeCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getGroupeCompletedEventArgs>(affiche_groupe);
                client.getGroupeAsync(id_metier, false);
            }
        }



        //permet d'afficher les module actuelement sélectioner
        public List<work.modules> lst_mod = new List<work.modules>();
        public void affiche_mod(object sender, EtudiantsVDLGestion.ServiceReference1.getModuleCompletedEventArgs e)
        {
            lst_mod = new List<work.modules>();

            foreach (var row in e.Result)
            {
                lst_mod.Add(new work.modules { id_programme = Int32.Parse(row[0]), id_groupe = Int32.Parse(row[1]), id_module = Int32.Parse(row[2]), nom_mod = row[3] });
            }

            if (((selectedCar != null) && (selectedCarMet != null)))
            {
                 EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                 client.getModuleCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getModuleCompletedEventArgs>(affiche_mod2);
                 client.getModuleAsync(Int32.Parse(selectedCarMet.id_metier), Int32.Parse(selectedCar.id_groupe), true);

                autoCompleteMod.ItemsSource = lst_mod;
            }


        }

        public void affiche_mod2(object sender, EtudiantsVDLGestion.ServiceReference1.getModuleCompletedEventArgs e)
        {
            lst_mod = new List<work.modules>();

            foreach (var row in e.Result)
            {
                lst_mod.Add(new work.modules { id_programme = Int32.Parse(row[0]), id_groupe = Int32.Parse(row[1]), id_module = Int32.Parse(row[2]), nom_mod = row[3] });
            }

            txtMod.DataContext = lst_mod;

        }


        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }



        private void addMet_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }


        //Ajoute un nouveau metier dans la abse de donner
        new composant.ConfirmPopUP blob;
        private void addMet_MouseLeftButtonUp(object sender, RoutedEventArgs e)
        {
           // System.Windows.MessageBox.Show(txtMet.Text);

            if (chekInsert(txtMet.Text))
            {
                EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                client.InsertMetierCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.InsertMetierCompletedEventArgs>(insert_met);
                client.InsertMetierAsync(txtMet.Text, -1);
            }
            else {


                blob = new composant.ConfirmPopUP();
                blob.lbprompt.Content = "Veuillez remplir le champs Métiers avant de proceder à l'insertion du nouveau metiers";
                blob.CancelButton.Visibility = Visibility.Collapsed;

            
            }


        }

        public void insert_met(object sender, EtudiantsVDLGestion.ServiceReference1.InsertMetierCompletedEventArgs e)
        {

            //réintitialise l'oedre des combobox
            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client2 = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client2.getMetierCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getMetierCompletedEventArgs>(affiche_metier);
            client2.getMetierAsync();
        }


        private void addGro_MouseLeftButtonUp(object sender, RoutedEventArgs e)
        {

            if (chekInsert(txtGro.Text))
            {
                EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                client.InsertGroupeCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.InsertGroupeCompletedEventArgs>(insert_Gro);
                client.InsertGroupeAsync(Int32.Parse(selectedCarMet.id_metier), txtGro.Text, -1);
            }
           else {

                blob = new composant.ConfirmPopUP();
                blob.lbprompt.Content = "Veuillez remplir le champ groupe anvat de priocerder a la creation d'un nouveau groupe";
                blob.CancelButton.Visibility = Visibility.Collapsed;
            }

        }


        public void insert_Gro(object sender, EtudiantsVDLGestion.ServiceReference1.InsertGroupeCompletedEventArgs e)
        {

            //réintitialise l'oedre des combobox
            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client2 = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client2.getGroupeCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getGroupeCompletedEventArgs>(affiche_groupe);
            client2.getGroupeAsync(Int32.Parse(selectedCarMet.id_metier), false);
        }


        private void addGro_MouseLeftButtonDown(object sender, RoutedEventArgs e)
        {

        }



        private void addMod_MouseLeftButtonUp(object sender, RoutedEventArgs e)
        {

            if (chekInsert(txtMod.Text))
            {
                EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                client.InsertModCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.InsertModCompletedEventArgs>(insert_Mod);
                client.InsertModAsync(Int32.Parse(selectedCar.id_groupe), txtMod.Text, -1);
            }
            else{
                blob = new composant.ConfirmPopUP();
                blob.lbprompt.Content = "Veuillez remplir le champ groupe anvat de priocerder a la creation d'un nouveau groupe";
                blob.CancelButton.Visibility = Visibility.Collapsed;
            
            }





        }

        public void insert_Mod(object sender, EtudiantsVDLGestion.ServiceReference1.InsertModCompletedEventArgs e)
        {

            //réintitialise l'oedre des combobox
            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client2 = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client2.getModuleCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getModuleCompletedEventArgs>(affiche_mod);
            client2.getModuleAsync(Int32.Parse(selectedCarMet.id_metier), Int32.Parse(selectedCar.id_groupe), false);
        }

        private void addMod_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }



        private void delMet_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }





        composant.ConfirmPopUP delWin = new composant.ConfirmPopUP();
        public work.Etudiants selectedEtu = new work.Etudiants();
        //action declencher lors du clic sur le bouton effacer
        private void delMet_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {


            if (selectedCarMet != null)
            {
                delWin = new composant.ConfirmPopUP();
                delWin.lbprompt.Content = "Voulez-vous vraiment supprimer le metier \n" + selectedCarMet.nom_metier + " tous ces groupes et modules seront Orhphelin";
                delWin.Closed += new EventHandler(delMet_Closed);
                delWin.Show();
            }

        }

        public void delMet_Closed(object sender, EventArgs e)
        {

            if (delWin.lbverif.Content.Equals("true"))
            {
                if (selectedEtu != null)
                {
                    EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                    client.delMetierCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.delMetierCompletedEventArgs>(del_metier);
                    client.delMetierAsync(Int32.Parse(selectedCarMet.id_metier));
                }
            }

        }


        public void del_metier(object sender, EtudiantsVDLGestion.ServiceReference1.delMetierCompletedEventArgs e)
        {

            //réintitialise l'oedre des combobox
            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client2 = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client2.getMetierCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getMetierCompletedEventArgs>(affiche_metier);
            client2.getMetierAsync();
        }



        private void delGro_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void delGro_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (selectedCar != null)
            {
                delWin = new composant.ConfirmPopUP();
                delWin.lbprompt.Content = "Voulez-vous vraiment supprimer le groupe \n" + selectedCar.nom_groupe + " tous modules seront Orhphelin";
                delWin.Closed += new EventHandler(delGro_Closed);
                delWin.Show();
            }
        }



        public void delGro_Closed(object sender, EventArgs e)
        {

            if (delWin.lbverif.Content.Equals("true"))
            {
                if (selectedCar != null)
                {
                    EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                    client.delGroupeCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.delGroupeCompletedEventArgs>(del_groupe);
                    client.delGroupeAsync(Int32.Parse(selectedCar.id_groupe));
                }
            }

        }


        public void del_groupe(object sender, EtudiantsVDLGestion.ServiceReference1.delGroupeCompletedEventArgs e)
        {

            //réintitialise l'oedre des combobox
            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client2 = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client2.getGroupeCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getGroupeCompletedEventArgs>(affiche_groupe);
            client2.getGroupeAsync(Int32.Parse(selectedCarMet.id_metier), false);
        }



        private void delMod_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }



        public work.modules selectedCarMod = new work.modules();
        private void delMod_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {

            selectedCarMod = (work.modules)autoCompleteMod.SelectedItem;

            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.delModCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.delModCompletedEventArgs>(del_mod);
            client.delModAsync(selectedCarMod.id_module);


        }


        public void del_mod(object sender, EtudiantsVDLGestion.ServiceReference1.delModCompletedEventArgs e)
        {

            //réintitialise l'oedre des combobox
            id_groupe = Int32.Parse(selectedCar.id_groupe);
            selectedCar = (work.Groupes)autoCompleteGro.SelectedItem;
            //System.Windows.MessageBox.Show(selectedCarMet.id_metier + "   " + selectedCar.id_groupe);

            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client2 = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client2.getModuleCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getModuleCompletedEventArgs>(affiche_mod);
            client2.getModuleAsync(Int32.Parse(selectedCarMet.id_metier), Int32.Parse(selectedCar.id_groupe), false);

        }


        public bool chekInsert(string input) {
            bool verif = true;

            if (input.Replace(" ","").Equals(""))
            {
                verif = false;
            }

            return verif;
        
        }

    }
}

