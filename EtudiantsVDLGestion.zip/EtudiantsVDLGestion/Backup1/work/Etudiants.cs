﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Collections.Generic;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;

namespace EtudiantsVDLGestion.work
{
    public class Etudiants
    {

        public int id_etudiants { get; set; }
        public string nom { get; set; }
        public string prenom { get; set; }
        public string age { get; set; }
        public int id_typ { get; set; }
        public string nomTyp { get; set; }
        public int id_groupe { get; set; }
        public string nomGroupe { get; set; }
        public string connecte { get; set; }
        public string nomUtilisateur { get; set; }
        public int id_met { get; set; }
        public string nom_met { get; set; }

    }

    public class Groupes
    {

        public string id_groupe { get; set; }
        public string nom_groupe { get; set; }

    }

    public class metiers
    {

        public string id_metier { get; set; }
        public string nom_metier { get; set; }

    }

    public class modules
    {

        public int id_programme { get; set; }
        public int id_groupe { get; set; }
        public int id_module { get; set; }
        public string nom_mod { get; set; }

    }

    public class questions
    {

        public int id_question { get; set; }
        public int id_module { get; set; }
        public string nom_qes { get; set; }
        public string point_qes { get; set; }
        public string multiQes { get; set; }

    }

    public class reponses
    {

        public int id_reponse { get; set; }
        public string intitule_rep { get; set; }
        public bool juste { get; set; }

    }

    public class questionnaire
    {

        public int id_qes { get; set; }
        public string intitule_qes { get; set; }
        // la liste suivant contiendra l'id des reponse leur intitulé et ci il sont déclarer juste 
        public List<reponses> lst_rep { get; set; }
        public double nbPoints { get; set; }

    }

    public class tests
    {
        public int id_test { get; set; }
        public string nom_tes { get; set; }
        public string tempsacc { get; set; }

    }

    public class droitsTest
    {
        public int id_etudiants { get; set; }
        public string nom { get; set; }
        public string prenom { get; set; }
        public string nomTyp { get; set; }
        public string nomUtilisateur { get; set; }
        public int id_droit { get; set; }
        public bool droits { get; set; }
        public BitmapImage imgDroits { get; set; }
    }

}