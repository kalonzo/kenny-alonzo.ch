﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace EtudiantsVDLGestion
{
    public partial class Portfolio : ChildWindow
    {
        public Portfolio()
        {
            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.getEtudiantsCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getEtudiantsCompletedEventArgs>(affiche_etudiants);
            client.getEtudiantsAsync(-1);
            InitializeComponent();
        }


        public void affiche_etudiants(object sender, EtudiantsVDLGestion.ServiceReference1.getEtudiantsCompletedEventArgs e)
        {

            List<work.Etudiants> et = new List<work.Etudiants>();


            foreach (var row in e.Result)
            {
                et.Add(new work.Etudiants { id_etudiants = Int32.Parse(row[0]), nom = row[1], prenom = row[2], age = row[3], id_typ = Int32.Parse(row[4]), nomTyp = row[5], id_groupe = Int32.Parse(row[6]), nomGroupe = row[7], connecte = row[8], nomUtilisateur = row[9], id_met = Int32.Parse(row[10]), nom_met = row[11] });
            }


            cbxEtu.ItemsSource = et;
            cbxEtu.DisplayMemberPath = "nom";
            cbxEtu.SelectionChanged += new SelectionChangedEventHandler(change_test);

        }


        public work.Etudiants selectedCarEtu = new work.Etudiants();
        public void change_test(object sender, SelectionChangedEventArgs e)
        {
            selectedCarEtu = (work.Etudiants)cbxEtu.SelectedItem;

            if(selectedCarEtu != null){
                EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                client.getTestByEtudiantsCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getTestByEtudiantsCompletedEventArgs>(affiche_test);
                client.getTestByEtudiantsAsync(selectedCarEtu.id_etudiants);
            }
    
        }



        //affichage les test du module ci existe
        List<work.tests> lstTest = new List<work.tests>();
        public void affiche_test(object sender, EtudiantsVDLGestion.ServiceReference1.getTestByEtudiantsCompletedEventArgs e)
        {

            lstTest = new List<work.tests>();
            //id_metier = -1;

            foreach (var row in e.Result)
            {
                lstTest.Add(new work.tests { id_test = Int32.Parse(row[0].ToString()), nom_tes = row[1], tempsacc = row[2] });
            }

            cbxTest.ItemsSource = lstTest;
            cbxTest.DisplayMemberPath = "nom_tes";
            cbxTest.SelectionChanged += new SelectionChangedEventHandler(affiche_corrige);
        }

      
        public void affiche_corrige(object sender, SelectionChangedEventArgs e)
        {
      

        }



        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}

