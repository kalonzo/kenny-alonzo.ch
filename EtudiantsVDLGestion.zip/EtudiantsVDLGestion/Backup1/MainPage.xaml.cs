﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Browser;

namespace EtudiantsVDLGestion
{
    public partial class MainPage : UserControl
    {

        //string plop = HtmlPage.Window.Invoke("DisplayUserName").ToString();
        string userLoc = "LOCAL";
        public MainPage()
        {

            string UserAccount = App.UserID;
             string[] str = UserAccount.Split('\\');
            


            InitializeComponent();
            Loaded += new RoutedEventHandler(Page_Loaded);
        }



        //authentification de la personne connecté l'utilisateur
        void Page_Loaded(object sender, RoutedEventArgs e)
        {

            // userVDL = HtmlPage.Window.Invoke("DisplayUserName").ToString();

            //System.Windows.MessageBox.Show(getCookie("test"));


            string UserAccount = App.UserID;
            string[] str = UserAccount.Split('\\');
            //  HtmlPage.Window.Invoke("DisplayUserName");

            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.WhoisAuthentifCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.WhoisAuthentifCompletedEventArgs>(read_user);
            client.WhoisAuthentifAsync(userLoc, getCookie("test"));
        }



        /////////////////////////////////////////////Module authentification


        //variable pour la carte d'identité de l'etudiants
        public int id_etudiant = new int();
        public int id_test = new int();
        public string nom_test = string.Empty;
        public string userSOI = string.Empty;
        public string userVDL = string.Empty;
        //definit si l'utilisateur est deja authetifie
        public bool auth = false;
        //le compte pour ce crefentiel est bloqué
        public bool bann = false;
        public int userVDLid = new int();
        public int id_groupe = new int();
        public string metier = string.Empty;
        public int id_metier = new int();

        //A true une fois l'utilisateur authentifié
        public bool authetif = false;
        public LogIN winLog = new LogIN();

        //ecriture lecture d'uncookie
        private bool setCookie(string key, string value)
        {
            if (string.IsNullOrEmpty(key) || string.IsNullOrEmpty(value))
            { return false; }
            DateTime dt = DateTime.Now + TimeSpan.FromDays(1);
            string s = key.Trim() + "=" + value.Trim()
                + ";expires=" + dt.ToString("R");
            HtmlPage.Document.SetProperty("cookie", s);
            return true;
        }



        private string getCookie(string key)
        {
            string[] cookies = HtmlPage.Document.Cookies.Split(';');
            foreach (string cookie in cookies)
            {
                string[] pair = cookie.Split('=');
                if (pair.Length == 2)
                {
                    if (pair[0].ToString() == key)
                        return pair[1];
                }
            }
            return null;
        }


        private void logOut_Click(object sender, RoutedEventArgs e)
        {
            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.deloCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.deloCompletedEventArgs>(closeApp);
            client.deloAsync(userVDLid);

            // HtmlPage.Window.Invoke("CloseWindow");
        }

        private void closeApp(object sender, EtudiantsVDLGestion.ServiceReference1.deloCompletedEventArgs e)
        {

            setCookie("test", "");
            HtmlPage.Window.Invoke("CloseWindow");

        }


        public string forName = string.Empty;

        //permet de lire l'identité de l'utilisateur lors de l'inscription
        void read_user(object sender, EtudiantsVDLGestion.ServiceReference1.WhoisAuthentifCompletedEventArgs e)
        {

            // System.Windows.MessageBox.Show(e.Result[12]);

            id_etudiant = Int32.Parse(e.Result[0]);
            id_test = Int32.Parse(e.Result[1]);
            nom_test = e.Result[2];
             forName = e.Result[12];



            userSOI = e.Result[3];
            //System.Windows.MessageBox.Show(e.Result[5]);
            if (e.Result[5].Equals("Y "))
            {
                auth = true;
            }
           // System.Windows.MessageBox.Show(e.Result[6]);
            if (e.Result[6].Equals("Y "))
            {

                bann = true;
            }
            userVDLid = Int32.Parse(e.Result[7]);
            id_groupe = Int32.Parse(e.Result[8]);
            metier = e.Result[9];
            id_metier = Int32.Parse(e.Result[10]);

            lbAsset.Content = userSOI.ToUpper();
            lbUser.Content = forName;
            //lbmetier.Content = metier;

           // System.Windows.MessageBox.Show(auth.ToString());

            //affichage de la fenetre de LogIN     
            if (!auth)
            {
                winLog.Closed += new EventHandler(PopupWindow_Closed);
                winLog.Show();
            }
            else
            {
                //Constructions 
                //Chargement des groupes
                EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client1 = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                client1.getRolesCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getRolesCompletedEventArgs>(load_Role);
                client1.getRolesAsync();
            }

        }

        //evenement qui ce declenche lors de la fermeture de la fenetre LogIN
        private void PopupWindow_Closed(object sender, EventArgs e)
        {


            userSOI = winLog.lbuserSOI.Content.ToString();
            userVDL = winLog.lbVDL.Content.ToString();
            setCookie("test", userVDL);
            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client5 = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client5.authCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.authCompletedEventArgs>(connect_user);
            client5.authAsync(userVDL);

        }

        public void connect_user(object sender, EtudiantsVDLGestion.ServiceReference1.authCompletedEventArgs e)
        {


            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.WhoisAuthentifCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.WhoisAuthentifCompletedEventArgs>(read_user);
            client.WhoisAuthentifAsync(userLoc, userVDL);


        }



        //Constructions de la GUI

        public int id_role = -1;

        public int selectedStack = new int();


        //liste d'objet contenant les groupes de travail à afficher
        public List<Button> btn = new List<Button>();
        //list de bouton pour l'affichage des modules
        public List<Button> btnMod = new List<Button>();

        public List<StackPanel> stack = new List<StackPanel>();

        //Construit des groupes
        void load_Role(object sender, EtudiantsVDLGestion.ServiceReference1.getRolesCompletedEventArgs e)
        {

            int i = 0;
            int y = 1;


            //eface la precedente configuration
            stackGroupe.Children.Clear();
            stackstack.Children.Clear();

            //Construction des boutons
            while (i < e.Result.Count)
            {
                string intituleBtn = string.Empty;
                intituleBtn = e.Result[i].nom_role.Replace(";", "\n");
                //ajout du bouton
                btn.Add(new Button());
                btn[i].Name = e.Result[i].id_roleEtudiantsVDL.ToString();

                btn[i].Content = intituleBtn;
                btn[i].Margin = new System.Windows.Thickness(18, 0, 0, 25 * y);
                btn[i].VerticalAlignment = VerticalAlignment.Bottom;
                btn[i].Height = 110;
                btn[i].Background = new SolidColorBrush(Colors.Red);
                btn[i].BorderBrush = new SolidColorBrush(Colors.White);
                btn[i].Foreground = new SolidColorBrush(Colors.White);
                btn[i].Click += new RoutedEventHandler(Onb2Click);
                btn[i].FontSize = 18;
                btn[i].Width = 160;


                //ajout du stack pannel en dessou du bouton afin d'acceulir les modules
                stack.Add(new StackPanel());
                stack[i].Name = e.Result[i].nom_role;
                stack[i].Margin = new System.Windows.Thickness(40);
                stack[i].Orientation = Orientation.Horizontal;
                //stack[i].Orientation = Orientation.Vertical;
                // stack[i].Height = 30;
                // stack[i].Width = 70;

                // Orientation="Horizontal" HorizontalAlignment="Center";


                //ajoute le composant à l'application
                stackGroupe.Children.Add(btn[i]);
                stackstack.Children.Add(stack[i]);
                i++;
                y++;

            }



        }


        //Actions déclencher lors de la sélection d'un role 

        //permet de détecter le bouton clicker et de rediriger l'evenement
        void Onb2Click(object sender, RoutedEventArgs e)
        {

            int i = 0;

            foreach (StackPanel pan in stack) { pan.Children.Clear(); };


            while (i < btn.Count)
            {
                if (btn[i].IsPressed)
                {
                    //stock temporairement l'indice tu tableau pour l'ajout des module
                    selectedStack = i;
                    EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                    client.getActionsCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getActionsCompletedEventArgs>(load_action);
                    client.getActionsAsync(Int32.Parse(btn[i].Name));
                }

                i++;
            }

        }



        //constructions des actions pour la gestion du role actuelle

        void load_action(object sender, EtudiantsVDLGestion.ServiceReference1.getActionsCompletedEventArgs e)
        {

            int i = 0;
            int y = 1;
            int d = 0;
            int plop = 0;
            bool btnCreate = false;

            btnMod.Clear();
            stack[selectedStack].Children.Clear();

            //Construction des boutons
            while (i < e.Result.Count)
            {
                string intituleBtn = string.Empty;
                intituleBtn = e.Result[i].nom_actions.Replace(";", "\n");
                //ajout du bouton
                btnMod.Add(new Button());
                // btnMod[i].Name = e.Result[i][1];

                if (e.Result[i].nom_actions.Contains(";"))
                {
                    btnMod[i].Content = intituleBtn;
                }
                else
                {
                    btnMod[i].Content = intituleBtn;
                }

                // btnMod[i].Name = e.Result[i].id_roleEtudiantsVDL.ToString();
                btnMod[i].Margin = new System.Windows.Thickness(18, 0, 0, 25 * y);
                btnMod[i].VerticalAlignment = VerticalAlignment.Bottom;
                btnMod[i].FontSize = 13;
                btnMod[i].Foreground = new SolidColorBrush(Colors.White);
                btnMod[i].Height = 70;
                btnMod[i].Width = 150;

                plop = 0;
                btnCreate = false;
                while (plop < e.Result.Count)
                {

                    //EtudiantsVDLGestion des droits a placé ici
                    // if (ActifTest[plop][1].Equals(e.Result[i][1]))
                    //{
                    //btnMod[i].Name = (ActifTest[plop][0]).ToString();
                    btnMod[i].Background = new SolidColorBrush(Colors.Green);
                    btnMod[i].BorderBrush = new SolidColorBrush(Colors.White);
                    btnMod[i].Foreground = new SolidColorBrush(Colors.White);
                    btnMod[i].Click += new RoutedEventHandler(clickFin);
                    btnCreate = true;
                    // }

                    plop++;
                }


                i++;
                y++;
            }

            d = 0;
            while (d < btnMod.Count)
            {

                stack[selectedStack].Children.Add(btnMod[d]);
                d++;
            }

        }




        bool addClient = false;
        bool addGroupe = false;
        bool addQes = false;
        bool addTest = false;
        bool DroitTest = false;
        void clickFin(object sender, RoutedEventArgs e)
        {

            //System.Windows.MessageBox.Show(btnMod.Count.ToString());

            if (btnMod.Count == 1)
            {
                //bouton zero represewnte l'ajout d'etudiants
                if (((btnMod[0].IsPressed) && (!addClient) && (btnMod[0].Content.Equals("Ajout / Suppression\n  d' Etudiants"))))
                {
                    AjoutEtudiants blob = new AjoutEtudiants();
                    blob.Closed += new EventHandler(addEtu_Closed);
                    blob.Show();

                    addClient = true;
                }
                if (((btnMod[0].IsPressed) && (!addQes) && (btnMod[0].Content.Equals("Ajout / Suppression\n  de Questions"))))
                {
                    AjoutQuestions blob = new AjoutQuestions();

                    blob.Show();
                    blob.Closed += new EventHandler(addQes_Closed);
                    addQes = true;
                }
                if (((btnMod[0].IsPressed) && (!addTest) && (btnMod[0].Content.Equals("Ajout / Suppression\n de  Tests"))))
                {
                    AjoutTests blob = new AjoutTests();

                    blob.Show();
                    blob.Closed += new EventHandler(addTest_Closed);
                    addTest = true;
                }

                if (((btnMod[0].IsPressed) && (!addTest) && (btnMod[0].Content.Equals("Ajout / Suppression\n des droits"))))
                {
                    AjoutDroitTest blob = new AjoutDroitTest();

                    blob.Show();
                    blob.Closed += new EventHandler(addDroits_Closed);
                    DroitTest = true;
                }

            }
            else
            {
                //bouton zero represewnte l'ajout d'etudiants
                if (((btnMod[0].IsPressed) && (!addClient) && (btnMod[0].Content.Equals("Ajout / Suppression\n  d' Etudiants"))))
                {
                    AjoutEtudiants blob = new AjoutEtudiants();
                    blob.Closed += new EventHandler(addEtu_Closed);
                    blob.Show();

                    addClient = true;
                }

                if (((btnMod[1].IsPressed) && (!addGroupe)))
                {
                    AjoutGroupes blob = new AjoutGroupes();

                    blob.Show();
                    blob.Closed += new EventHandler(addGro_Closed);
                    addGroupe = true;

                }

                if (((btnMod[0].IsPressed) && (!addQes) && (btnMod[0].Content.Equals("Ajout / Suppression\n  de Questions"))))
                {
                    AjoutQuestions blob = new AjoutQuestions();

                    blob.Show();
                    blob.Closed += new EventHandler(addQes_Closed);
                    addQes = true;
                }

            }

        }

        private void addEtu_Closed(object sender, EventArgs e)
        {
            addClient = false;
        }

        private void addGro_Closed(object sender, EventArgs e)
        {
            addGroupe = false;
        }

        private void addQes_Closed(object sender, EventArgs e)
        {
            addQes = false;
        }

        private void addTest_Closed(object sender, EventArgs e)
        {
            addTest = false;
        }

        private void addDroits_Closed(object sender, EventArgs e)
        {
            DroitTest = false;
        }

        void finEtudiants(object sender, EventArgs e)
        {


        }

        private void btnportfolios_Click(object sender, RoutedEventArgs e)
        {

            Portfolio blob = new Portfolio();

            blob.Show();

        }
      }
    }