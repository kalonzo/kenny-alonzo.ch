﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;

namespace EtudiantsVDLGestion
{
    public partial class AjoutDroitTest : ChildWindow
    {
        public AjoutDroitTest()
        {
            InitializeComponent();

            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.getMetierCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getMetierCompletedEventArgs>(affiche_metier);
            client.getMetierAsync();
        }

        public void cleanGUI()
        {

            cbxModTest.ItemsSource = null;
            cbxGroTest.ItemsSource = null;
            // cbxTest.ItemsSource = null;
            dgetudiants.ItemsSource = null;


        }

        //affichage metier
        public void affiche_metier(object sender, EtudiantsVDLGestion.ServiceReference1.getMetierCompletedEventArgs e)
        {

            lst_metier = new List<work.metiers>();
            id_metier = -1;
            id_groupe = -1;
            id_module = -1;
            id_questions = -1;

            //réinitialize la GUI
            cleanGUI();



            foreach (var row in e.Result)
            {
                lst_metier.Add(new work.metiers { id_metier = row[0].ToString(), nom_metier = row[1] });

            }

            cbxMetTest.ItemsSource = lst_metier;
            cbxMetTest.DisplayMemberPath = "nom_metier";
            cbxMetTest.SelectionChanged += new SelectionChangedEventHandler(cb_SelectionChanged);
            cbxMetTest.SelectedItem = "Informatique";

        }

        //action declencher lors du changement de metier
        void cb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            selectedCarMet = (work.metiers)cbxMetTest.SelectedItem;
            id_metier = Int32.Parse(selectedCarMet.id_metier);
            cleanGUI();
            //Population des combobox groupe

            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.getGroupeCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getGroupeCompletedEventArgs>(affiche_groupe);
            client.getGroupeAsync(id_metier, false);
        }


        //affichage des groupe
        public void affiche_groupe(object sender, EtudiantsVDLGestion.ServiceReference1.getGroupeCompletedEventArgs e)
        {

            lst_groupe = new List<work.Groupes>();
            cbxModTest.ItemsSource = null;
            cleanGUI();
            //id_metier = -1;

            foreach (var row in e.Result)
            {
                lst_groupe.Add(new work.Groupes { id_groupe = row[0].ToString(), nom_groupe = row[1] });
            }

            cbxGroTest.ItemsSource = lst_groupe;
            cbxGroTest.DisplayMemberPath = "nom_groupe";
            cbxGroTest.SelectionChanged += new SelectionChangedEventHandler(cbGro_SelectionChanged);
            cbxGroTest.SelectedItem = "PDT";
        }




        //affichage les test du module ci existe
        List<work.tests> lstTest = new List<work.tests>();
        public void affiche_test(object sender, EtudiantsVDLGestion.ServiceReference1.getTestCompletedEventArgs e)
        {

            lstTest = new List<work.tests>();
            //id_metier = -1;

            foreach (var row in e.Result)
            {
                //System.Windows.MessageBox.Show(row[0]);
                lstTest.Add(new work.tests { id_test = Int32.Parse(row[0].ToString()), nom_tes = row[1], tempsacc = row[2] });
            }

            cbxTest.ItemsSource = lstTest;
            cbxTest.DisplayMemberPath = "nom_tes";
            cbxTest.SelectionChanged += new SelectionChangedEventHandler(cb_SelectionChangedTest);
        }


        public int id_test = new int();
        //afichage du test 
        public work.tests selectedCarTest = new work.tests();
        //permet d'encapsuler l'id du test
        void cb_SelectionChangedTest(object sender, SelectionChangedEventArgs e)
        {
            selectedCarTest = (work.tests)cbxTest.SelectedItem;

            if (selectedCarTest != null)
            {
                //todohere
                id_test = selectedCarTest.id_test;
                // System.Windows.MessageBox.Show(id_test.ToString());

                EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                client.getEtuByTestCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getEtuByTestCompletedEventArgs>(affiche_etudiants);
                client.getEtuByTestAsync(id_test, id_groupe);
            }

        }


        public void affiche_etudiants(object sender, EtudiantsVDLGestion.ServiceReference1.getEtuByTestCompletedEventArgs e)
        {

            List<work.droitsTest> et = new List<work.droitsTest>();

            //  bool verif = true;



            // imgDroits.Source = new BitmapImage(new Uri("myPicture.jpg", UriKind.RelativeOrAbsolute));
            //LayoutRoot.Children.Add(myImage);



            Image myImage = new Image();
            foreach (var row in e.Result)
            {
                // System.Windows.MessageBox.Show(row[6]);
                if (row[6].ToString().Replace(" ", "").Equals("Y"))
                {

                    et.Add(new work.droitsTest { id_etudiants = Int32.Parse(row[0]), nom = row[1], prenom = row[2], nomTyp = row[3], nomUtilisateur = row[4], id_droit = Int32.Parse(row[5]), droits = true, imgDroits = new BitmapImage(new Uri("/EtudiantsVDLGestion;component/image/cocheVerte.jpg", UriKind.RelativeOrAbsolute)) });
                    //myImage.Source = new BitmapImage(new Uri("/EtudiantsVDLGestion;component/image/cocheVerte.jpg", UriKind.RelativeOrAbsolute));
                    // verif = true;
                }
                else
                {
                    et.Add(new work.droitsTest { id_etudiants = Int32.Parse(row[0]), nom = row[1], prenom = row[2], nomTyp = row[3], nomUtilisateur = row[4], id_droit = Int32.Parse(row[5]), droits = false, imgDroits = new BitmapImage(new Uri("/EtudiantsVDLGestion;component/image/supprimer.jpg", UriKind.RelativeOrAbsolute)) });
                    // myImage.Source = new BitmapImage(new Uri("/EtudiantsVDLGestion;component/image/supprimer.jpg", UriKind.RelativeOrAbsolute));
                    // verif = false;
                }
            }


            //System.Windows.MessageBox.Show(e.Result.ToList().ToString());
            // dgetudiants.DataContext = e.Result;
            dgetudiants.ItemsSource = et;

        }



        int id_metier = new int();
        int id_groupe = new int();
        int id_module = new int();
        int id_questions = new int();
        List<work.metiers> lst_metier = new List<work.metiers>();


        work.metiers selectedCarMet = new work.metiers();

        public List<work.Groupes> lst_groupe = new List<work.Groupes>();


        public work.Groupes selectedCar = new work.Groupes();
        //action declencher lors du changement de groupe
        void cbGro_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedCar = (work.Groupes)cbxGroTest.SelectedItem;
            cbxModTest.ItemsSource = null;
            cbxTest.ItemsSource = null;
            // System.Windows.MessageBox.Show(selectedCar.nom_groupe);


            if (cbxTest.SelectedIndex == -1)
            {
                if (selectedCar != null)
                {
                    id_groupe = Int32.Parse(selectedCar.id_groupe);

                    //Population des combobox groupe
                    EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                    client.getModuleCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getModuleCompletedEventArgs>(affiche_mod);
                    client.getModuleAsync(Int32.Parse(selectedCarMet.id_metier), Int32.Parse(selectedCar.id_groupe), false);
                }
            }
            else
            {

                if (selectedCar != null)
                {
                    id_groupe = Int32.Parse(selectedCar.id_groupe);

                    //Population des combobox groupe
                    EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                    client.getModuleCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getModuleCompletedEventArgs>(affiche_mod);
                    client.getModuleAsync(Int32.Parse(selectedCarMet.id_metier), Int32.Parse(selectedCar.id_groupe), false);
                }

            }
        }


        //Affichage des modules
        public List<work.modules> lst_mod = new List<work.modules>();
        public void affiche_mod(object sender, EtudiantsVDLGestion.ServiceReference1.getModuleCompletedEventArgs e)
        {
            lst_mod = new List<work.modules>();

            foreach (var row in e.Result)
            {
                lst_mod.Add(new work.modules { id_programme = Int32.Parse(row[0]), id_groupe = Int32.Parse(row[1]), id_module = Int32.Parse(row[2]), nom_mod = row[3] });
            }

            cbxModTest.ItemsSource = lst_mod;
            cbxModTest.DisplayMemberPath = "nom_mod";
            cbxModTest.SelectionChanged += new SelectionChangedEventHandler(cbMod_SelectionChanged);
            //cbxMod.SelectedIndex = 0;
        }

        public work.modules selectedCarMod = new work.modules();
        void cbMod_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedCarMod = (work.modules)cbxModTest.SelectedItem;
            // System.Windows.MessageBox.Show(selectedCar.nom_groupe);

            if (selectedCarMod != null)
            {
                id_module = selectedCarMod.id_module;

                // System.Windows.MessageBox.Show(selectedCarMod.id_module.ToString());
                //Affichage des test du module (ci exist)
                EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                client.getTestCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getTestCompletedEventArgs>(affiche_test);
                client.getTestAsync(selectedCarMod.id_module);

            }
        }


        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }


        //popup de confirmation pour la modifications des droits
        composant.ConfirmPopUP bob = new composant.ConfirmPopUP();
        private void imgDroits_MouseLeftButtonUp_1(object sender, MouseButtonEventArgs e)
        {
            selectedEtu = (work.droitsTest)dgetudiants.SelectedItem;


            if (selectedEtu != null)
            {//changement du droits test
                id_test = selectedCarTest.id_test;

                bob = new composant.ConfirmPopUP();
                bob.lbprompt.Content = "Voulez-vous vraiment supprimer " + selectedEtu.nom + " " + selectedEtu.prenom + "\ntous ses résultats seront supprimés";
                bob.Closed += new EventHandler(bob_Closed);
                bob.Show();

            }

        }

        //modifications du droits tes pour l'etudiants selectioné
        public work.droitsTest selectedEtu = new work.droitsTest();
        public void bob_Closed(object sender, EventArgs e)
        {

            if (bob.lbverif.Content.Equals("true"))
            {
                if (selectedEtu != null)
                {

                    // System.Windows.MessageBox.Show(selectedCarTest.id_test.ToString() + "  " + id_test.ToString());
                    EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                    client.InsertDroitsCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.InsertDroitsCompletedEventArgs>(insert_droits);
                    client.InsertDroitsAsync(selectedCarTest.id_test, selectedEtu.id_droit, selectedEtu.id_etudiants, selectedEtu.droits);
                }
            }

        }

        public void insert_droits(object sender, EtudiantsVDLGestion.ServiceReference1.InsertDroitsCompletedEventArgs e)
        {
            //Rafraichie la vue  datagrid
            dgetudiants.ItemsSource = null;
            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.getEtuByTestCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getEtuByTestCompletedEventArgs>(affiche_etudiants);
            client.getEtuByTestAsync(id_test, id_groupe);


        }







    }


}

