﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace EtudiantsVDLGestion
{
    public partial class AddRep : ChildWindow
    {
        public int id_modu = new int();
        public AddRep(int plop)
        {
            id_modu = plop;

            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.getRepsCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getRepsCompletedEventArgs>(affiche_rep);
            client.getRepsAsync(id_modu);

            InitializeComponent();
        }

       
        public List<work.reponses> lst_rep = new List<work.reponses>();
        //Affichage des réponse dans le datagrid
        public void affiche_rep(object sender, EtudiantsVDLGestion.ServiceReference1.getRepsCompletedEventArgs e)
        {

            bool verif = new bool();
            foreach (var row in e.Result)
            {

                if (row[2].Equals("Y "))
                {
                    verif = true;
                }
                else
                {
                    verif = false;
                }
                lst_rep.Add(new work.reponses { id_reponse = Int32.Parse(row[0]), intitule_rep = row[1], juste = verif });
            }


            dgRep.ItemsSource = lst_rep;

        }




        public work.reponses selectedEtu = new work.reponses();
        //action declencher lors du clic sur le bouton effacer
        private void OKButton_Click(object sender, RoutedEventArgs e)
        {

            selectedEtu = (work.reponses)dgRep.SelectedItem;

            if (selectedEtu != null)
            {
                id_rep.Content = selectedEtu.id_reponse.ToString();
            }


            if (newQes.IsPressed)
            {

                newRep.Content = "Y";

                //System.Windows.MessageBox.Show(newRep.Content.ToString());
            }
            else
            {
                newRep.Content = "N";
            }

            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        //popup de confirmation
        composant.ConfirmPopUP bob = new composant.ConfirmPopUP();
        private void suppRep_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {

            selectedEtu = (work.reponses)dgRep.SelectedItem;


            if (selectedEtu != null)
            {//changement du droits test
                bob = new composant.ConfirmPopUP();
                bob.lbprompt.Content = "Voulez-vous vraiment supprimer la réponse " + selectedEtu.intitule_rep + " \nLa réponse disparaitra de tous les questionnaire ou elle etaits affécté";
                bob.Closed += new EventHandler(bob_Closed);
                bob.Show();

            }

        }

        //ecouteur de la fenetre
        public void bob_Closed(object sender, EventArgs e)
        {

            if (bob.lbverif.Content.Equals("true"))
            {

                selectedEtu = (work.reponses)dgRep.SelectedItem;
                    // System.Windows.MessageBox.Show(selectedCarTest.id_test.ToString() + "  " + id_test.ToString());
                    EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                    client.delRepCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.delRepCompletedEventArgs>(del_rep);
                    client.delRepAsync(selectedEtu.id_reponse);
                
            }
        }

        public void del_rep(object sender, EtudiantsVDLGestion.ServiceReference1.delRepCompletedEventArgs e) {
            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.getRepsCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getRepsCompletedEventArgs>(affiche_rep);
            client.getRepsAsync(id_modu);
        }



    }
}

