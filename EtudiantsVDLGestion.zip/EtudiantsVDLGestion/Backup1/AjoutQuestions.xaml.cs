﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;

//using System.Windows.Media.ImageSource;

namespace EtudiantsVDLGestion
{
    public partial class AjoutQuestions : ChildWindow
    {
        public AjoutQuestions()
        {
            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.getMetierCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getMetierCompletedEventArgs>(affiche_metier);
            client.getMetierAsync();
            InitializeComponent();
        }

        //réinitialize les composants de la GUI
        public void cleanGUI()
        {

            cbxMod.ItemsSource = null;
            cbxGro.ItemsSource = null;
            cbxQes.ItemsSource = null;
            // cbxTest.ItemsSource = null;
            // dgetudiants.ItemsSource = null;


        }


        int id_metier = new int();
        int id_groupe = new int();
        int id_module = new int();
        int id_questions = new int();
        List<work.metiers> lst_metier = new List<work.metiers>();

        //affichage metier
        public void affiche_metier(object sender, EtudiantsVDLGestion.ServiceReference1.getMetierCompletedEventArgs e)
        {

            cleanGUI();
            lst_metier = new List<work.metiers>();
            id_metier = -1;
            id_groupe = -1;
            id_module = -1;
            id_questions = -1;


            foreach (var row in e.Result)
            {
                lst_metier.Add(new work.metiers { id_metier = row[0].ToString(), nom_metier = row[1] });

            }


            cbxMet.ItemsSource = lst_metier;
            cbxMet.DisplayMemberPath = "nom_metier";
            cbxMet.SelectionChanged += new SelectionChangedEventHandler(cb_SelectionChanged);
            cbxMet.SelectedItem = "Informatique";

        }


        work.metiers selectedCarMet = new work.metiers();

        //action declencher lors du changement de metier
        void cb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            cleanGUI();
            selectedCarMet = (work.metiers)cbxMet.SelectedItem;
            id_metier = Int32.Parse(selectedCarMet.id_metier);

            //Population des combobox groupe

            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.getGroupeCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getGroupeCompletedEventArgs>(affiche_groupe);
            client.getGroupeAsync(id_metier, false);
        }


        public List<work.Groupes> lst_groupe = new List<work.Groupes>();
        //affichage des groupe
        public void affiche_groupe(object sender, EtudiantsVDLGestion.ServiceReference1.getGroupeCompletedEventArgs e)
        {


            lst_groupe = new List<work.Groupes>();
            //id_metier = -1;

            foreach (var row in e.Result)
            {
                lst_groupe.Add(new work.Groupes { id_groupe = row[0].ToString(), nom_groupe = row[1] });
            }


            cbxGro.ItemsSource = lst_groupe;
            cbxGro.DisplayMemberPath = "nom_groupe";
            cbxGro.SelectionChanged += new SelectionChangedEventHandler(cbGro_SelectionChanged);
            cbxGro.SelectedItem = "PDT";
        }


        public work.Groupes selectedCar = new work.Groupes();
        //action declencher lors du changement de groupe
        void cbGro_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedCar = (work.Groupes)cbxGro.SelectedItem;
            // System.Windows.MessageBox.Show(selectedCar.nom_groupe);

            if (selectedCar != null)
            {
                id_groupe = Int32.Parse(selectedCar.id_groupe);

                //Population des combobox groupe
                EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                client.getModuleCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getModuleCompletedEventArgs>(affiche_mod);
                client.getModuleAsync(Int32.Parse(selectedCarMet.id_metier), Int32.Parse(selectedCar.id_groupe), false);
            }
        }


        //Affichage des modules
        public List<work.modules> lst_mod = new List<work.modules>();
        public void affiche_mod(object sender, EtudiantsVDLGestion.ServiceReference1.getModuleCompletedEventArgs e)
        {
            lst_mod = new List<work.modules>();

            foreach (var row in e.Result)
            {
                lst_mod.Add(new work.modules { id_programme = Int32.Parse(row[0]), id_groupe = Int32.Parse(row[1]), id_module = Int32.Parse(row[2]), nom_mod = row[3] });
            }

            cbxMod.ItemsSource = lst_mod;
            cbxMod.DisplayMemberPath = "nom_mod";
            cbxMod.SelectionChanged += new SelectionChangedEventHandler(cbMod_SelectionChanged);
            //cbxMod.SelectedIndex = 0;
        }

        public work.modules selectedCarMod = new work.modules();
        void cbMod_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedCarMod = (work.modules)cbxMod.SelectedItem;
            // System.Windows.MessageBox.Show(selectedCar.nom_groupe);

            if (selectedCarMod != null)
            {
                id_module = selectedCarMod.id_module;

                EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                client.getQesCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getQesCompletedEventArgs>(affiche_qes);
                client.getQesAsync(id_module);

            }
        }

        public List<work.questions> lst_qes = new List<work.questions>();
        public void affiche_qes(object sender, EtudiantsVDLGestion.ServiceReference1.getQesCompletedEventArgs e)
        {


            lst_qes = new List<work.questions>();

            foreach (var row in e.Result)
            {
                lst_qes.Add(new work.questions { id_question = Int32.Parse(row[0]), id_module = Int32.Parse(row[1]), nom_qes = row[2], point_qes = row[3], multiQes = row[4] });
            }


            cbxQes.ItemsSource = lst_qes;
            cbxQes.DisplayMemberPath = "nom_qes";
            cbxQes.SelectionChanged += new SelectionChangedEventHandler(cbQes_SelectionChanged);
        }

        public work.questions selectedCarQes = new work.questions();
        //action declencher lors du changement de groupe
        void cbQes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cbxQes.SelectedIndex != -1)
            {
                stckReps.Children.Clear();
                stckRep = new List<StackPanel>();
                //rdRep = new List<RadioButton>();
                txtRep = new List<TextBox>();
                chkRep = new List<CheckBox>();
                imgRep = new List<Button>();
                selectedCarQes = (work.questions)cbxQes.SelectedItem;
                stackQuest.Visibility = System.Windows.Visibility.Visible;

                if (selectedCarQes != null)
                {
                    id_questions = selectedCarQes.id_question;

                    txtInti.Text = "";
                    nbPoint.Text = "";
                    imgDelQes.Visibility = Visibility.Visible;

                    txtInti.Text = selectedCarQes.nom_qes;
                    nbPoint.Text = selectedCarQes.point_qes;

                    //construction de questionnaire
                    EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                    client.getRepCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getRepCompletedEventArgs>(construct_qes);
                    client.getRepAsync(id_questions);
                }
            }

        }

        //variable local pour les reponse 
        public List<work.reponses> lst_rep = new List<work.reponses>();
        public List<StackPanel> stckRep = new List<StackPanel>();
       // public List<RadioButton> rdRep = new List<RadioButton>();
        public List<TextBox> txtRep = new List<TextBox>();
        public List<CheckBox> chkRep = new List<CheckBox>();
        public List<Button> imgRep = new List<Button>();

        public void construct_qes(object sender, EtudiantsVDLGestion.ServiceReference1.getRepCompletedEventArgs e)
        {

            //efface le formulaire pour la creation du suivant
            stckReps.Children.Clear();
            stckRep = new List<StackPanel>();
            //rdRep = new List<RadioButton>();
            txtRep = new List<TextBox>();
            chkRep = new List<CheckBox>();
            imgRep = new List<Button>();



            int i = 0;
            foreach (var row in e.Result)
            {

                //  System.Windows.MessageBox.Show(row[2]);
                //Creation du panel poour la réponse
                stckRep.Add(new StackPanel());
                stckRep[i].Orientation = Orientation.Horizontal;

                //rdRep.Add(new RadioButton());
                //rdRep[i].Margin = new Thickness(0, 0, 20, 0);

                txtRep.Add(new TextBox());
                txtRep[i].Text = row[1];
                txtRep[i].Width = 200;

                chkRep.Add(new CheckBox());

                if (row[2].Equals("Y "))
                {
                    chkRep[i].IsChecked = true;
                }


                imgRep.Add(new Button());
                // imgRep[i].Height = 16;
                //imgRep[i].Width = 16;
                imgRep[i].Content = "Enlever";
                imgRep[i].Click += new RoutedEventHandler(sup_ques);
                imgRep[i].Name = row[0];
                imgRep[i].Style = new System.Windows.Style(typeof(System.Windows.Controls.Button)) ;


                //stckRep[i].Children.Add(rdRep[i]);
                stckRep[i].Children.Add(txtRep[i]);
                stckRep[i].Children.Add(chkRep[i]);
                stckRep[i].Children.Add(imgRep[i]);
                stckReps.Children.Add(stckRep[i]);

                i++;
            }
        }

        public int selectedrep = new int();
        private void sup_ques(object sender, RoutedEventArgs e)
        {
            int i = 0;
            selectedrep = 0;
            while (i < imgRep.Count)
            {
                if (imgRep[i].IsPressed)
                {
                    //permet de retrouver l'indice du bouton selevctionner 
                    selectedrep = i;
                    stckRep[i].Children.Clear();
                    //tckRep.RemoveAt(i);
                    EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                    client.delrepToQestCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.delrepToQestCompletedEventArgs>(del_qest);
                    //la reponse a enlever du questionnaire existe
                    if (imgRep[i].Name.ToString() != "")
                    {
                        client.delrepToQestAsync(id_questions, Int32.Parse(imgRep[i].Name.ToString()));
                    }
                    else {
                        //Deconstruit le composant du questionnaire

                        imgRep.RemoveAt(i);
                        stckRep.RemoveAt(i);
                    }

                }
                i++;
            }
        }



        public void del_qest(object sender, EtudiantsVDLGestion.ServiceReference1.delrepToQestCompletedEventArgs e)
        {
            //Deconstruit le composant du questionnaire
            imgRep.RemoveAt(selectedrep);
            stckRep.RemoveAt(selectedrep);

            selectedrep = 0;

        }


        //Ajout de question a une réponse
        // public AddRep addrep = new AddRep();
        public AddRep addrep;
        private void Image_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {

            addrep = new AddRep(id_module);
            addrep.Closed += new EventHandler(addQes_Closed);
            addrep.Show();

        }

        private void addQes_Closed(object sender, EventArgs e)
        {

            //System.Windows.MessageBox.Show(stckRep.Count.ToString());

            //creation d'une nouvelle question
            if (addrep.newRep.Content.Equals("Y"))
            {

                int i = 0;
                while (i < imgRep.Count)
                {
                    i++;
                }


                //Creation du panel poour la réponse
                stckRep.Add(new StackPanel());
                stckRep[i].Orientation = Orientation.Horizontal;

                //rdRep.Add(new RadioButton());
               // rdRep[i].Margin = new Thickness(0, 0, 20, 0);
               // rdRep[i].Visibility = Visibility.Collapsed;

                txtRep.Add(new TextBox());
                //txtRep[imgRep.Count + 1].Text = row[1];
                txtRep[i].Width = 200;

                chkRep.Add(new CheckBox());


                imgRep.Add(new Button());
                // imgRep[i].Height = 16;
                //imgRep[i].Width = 16;
                imgRep[i].Content = "Enlever";
                imgRep[i].Style = new System.Windows.Style(typeof(System.Windows.Controls.Button));
                imgRep[i].Click += new RoutedEventHandler(sup_ques);
                //-1 permet d'indiquer que la reponse n'existe pas 
                // imgRep[i].Name = "-1";


                //stckRep[i].Children.Add(rdRep[i]);
                stckRep[i].Children.Add(txtRep[i]);
                stckRep[i].Children.Add(chkRep[i]);
                stckRep[i].Children.Add(imgRep[i]);

                stckReps.Children.Add(stckRep[i]);
            }
            else
            {
                //reprend une des réponse de la base

                //controle ci l'utilisateur a desactiver la fenetre 
                if (addrep.id_rep.Content.ToString() != "")
                {
                    EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                    client.getRepToAddCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getRepToAddCompletedEventArgs>(construct1_qes);
                    client.getRepToAddAsync(Int32.Parse(addrep.id_rep.Content.ToString()));
                }

            }
        }


        //construction de la réponse de plus a ajouter
        public void construct1_qes(object sender, EtudiantsVDLGestion.ServiceReference1.getRepToAddCompletedEventArgs e)
        {


            int i = 0;
            //permet de retrouver l'indice des panneau pour le rajout du nouveau
            while (i < stckRep.Count) { i++; }

            foreach (var row in e.Result)
            {

                //  System.Windows.MessageBox.Show(row[2]);
                //Creation du panel poour la réponse
                stckRep.Add(new StackPanel());
                stckRep[i].Orientation = Orientation.Horizontal;

                //rdRep.Add(new RadioButton());
                //rdRep[i].Margin = new Thickness(0, 0, 20, 0);
               // rdRep[i].Visibility = Visibility.Collapsed;

                txtRep.Add(new TextBox());
                txtRep[i].Text = row[1];
                txtRep[i].Width = 200;

                chkRep.Add(new CheckBox());

                if (row[2].Equals("Y "))
                {
                    chkRep[i].IsChecked = true;
                }


                imgRep.Add(new Button());
                // imgRep[i].Height = 16;
                //imgRep[i].Width = 16;
                imgRep[i].Content = "Enlever";
                imgRep[i].Style = new System.Windows.Style(typeof(System.Windows.Controls.Button));
                imgRep[i].Click += new RoutedEventHandler(sup_ques);
                imgRep[i].Name = row[0];

               // stckRep[i].Children.Add(rdRep[i]);
                stckRep[i].Children.Add(txtRep[i]);
                stckRep[i].Children.Add(chkRep[i]);
                stckRep[i].Children.Add(imgRep[i]);
                stckReps.Children.Add(stckRep[i]);

                i++;

            }

        }


        //Creation de nouvel questions 
        public bool addNewQes = false;
        public composant.ConfirmPopUP advertismentNewTest = new composant.ConfirmPopUP();
        private void addQes_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (addNewQes)
            {
                cbxMet.IsEnabled = true;
                cbxGro.IsEnabled = true;
                cbxMod.IsEnabled = true;
                cbxQes.IsEnabled = true;
                stackQuest.Visibility = System.Windows.Visibility.Collapsed;
                addNewQes = false;
            }
            else
            {

                if (((cbxMet.SelectedIndex != -1) && (cbxGro.SelectedIndex != -1) && (cbxMod.SelectedIndex != -1)))
                {
                    //initialize l'id de la question pour une nouvel questions
                    id_questions = -1;
                    stckReps.Children.Clear();
                    stckRep = new List<StackPanel>();
                   // rdRep = new List<RadioButton>();
                    txtRep = new List<TextBox>();
                    chkRep = new List<CheckBox>();
                    imgRep = new List<Button>();

                    cbxMet.IsEnabled = false;
                    cbxGro.IsEnabled = false;
                    cbxMod.IsEnabled = false;
                    cbxQes.IsEnabled = false;

                    stackQuest.Visibility = System.Windows.Visibility.Visible;

                    txtInti.Text = "";
                    nbPoint.Text = "0.6";
                    imgDelQes.Visibility = Visibility.Collapsed;

                }
                else
                {
                    //Instance d'une fenétre Warning
                    advertismentNewTest = new composant.ConfirmPopUP();
                    advertismentNewTest.CancelButton.Visibility = Visibility.Collapsed;
                    advertismentNewTest.lbprompt.Content = "Veuillez sélectionner un metiers un groupe et un module\navant de proceder à la création d'une nouvel questions";
                    advertismentNewTest.Show();
                }

                addNewQes = true;
            }




        }


        //lecture du formulaire pour l'insertion ou la mise a jour du formulaire
        private void insertQest_Click(object sender, RoutedEventArgs e)
        {
            cbxMet.IsEnabled = true;
            cbxGro.IsEnabled = true;
            cbxMod.IsEnabled = true;
            cbxQes.IsEnabled = true;

            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.InsertQestCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.InsertQestCompletedEventArgs>(insert_qet);



            int i = 0;
            int cntJuste = 0;

            System.Collections.ObjectModel.ObservableCollection<System.Collections.ObjectModel.ObservableCollection<string>> lstrep = new System.Collections.ObjectModel.ObservableCollection<System.Collections.ObjectModel.ObservableCollection<string>>();
            string juste = string.Empty;


            while (i < imgRep.Count)
            {
                if (chkRep[i].IsChecked == true)
                {
                    juste = "Y";
                    cntJuste++;
                }
                else
                {
                    juste = "N";
                }

                lstrep.Add(new System.Collections.ObjectModel.ObservableCollection<string> { imgRep[i].Name.ToString(), txtRep[i].Text, juste });
                i++;
            }



            if (cntJuste != 1)
            {
                //questions a multiple choix 
                client.InsertQestAsync(id_module, id_questions, txtInti.Text.ToString(), nbPoint.Text.ToString(), "Y", lstrep);
            }
            else
            {
                client.InsertQestAsync(id_module, id_questions, txtInti.Text.ToString(), nbPoint.Text.ToString(), "N", lstrep);
            }


        }

        public void insert_qet(object sender, EtudiantsVDLGestion.ServiceReference1.InsertQestCompletedEventArgs e)
        {
            id_questions = -1;
            stckReps.Children.Clear();
            stckRep = new List<StackPanel>();
           // rdRep = new List<RadioButton>();
            txtRep = new List<TextBox>();
            chkRep = new List<CheckBox>();
            imgRep = new List<Button>();
            stackQuest.Visibility = Visibility.Collapsed;
            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.getQesCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getQesCompletedEventArgs>(affiche_qes);
            client.getQesAsync(id_module);
        }


        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        composant.ConfirmPopUP bob = new composant.ConfirmPopUP();

        //permet d'effacer le questionnaire en complet
        private void imgDelQes_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            bob = new composant.ConfirmPopUP();
            bob.lbprompt.Content = "Voulez vous vraiment supprimer la question\n\"" + txtInti.Text + "\" Veuillez passez par le sous menu des réponse pour supprimer les réponses";
            bob.Closed += new EventHandler(bob_Closed);
            bob.Show();

        }

        //Ecouteur pour la fenetre
        public void bob_Closed(object sender, EventArgs e)
        {

            if (bob.lbverif.Content.Equals("true"))
            {
                cbxMet.IsEnabled = true;
                cbxGro.IsEnabled = true;
                cbxMod.IsEnabled = true;
                cbxQes.IsEnabled = true;

                //supprime la questions de la base

                EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                client.delQestCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.delQestCompletedEventArgs>(del_qest);
                client.delQestAsync(id_questions);

            }

        }

        public void del_qest(object sender, EtudiantsVDLGestion.ServiceReference1.delQestCompletedEventArgs e)
        {
            //efface la GUI questionnaire 
            id_questions = -1;
            stckReps.Children.Clear();
            stckRep = new List<StackPanel>();
            //rdRep = new List<RadioButton>();
            txtRep = new List<TextBox>();
            chkRep = new List<CheckBox>();
            imgRep = new List<Button>();
            stackQuest.Visibility = Visibility.Collapsed;

            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.getQesCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getQesCompletedEventArgs>(affiche_qes);
            client.getQesAsync(id_module);


        }

    }
}

