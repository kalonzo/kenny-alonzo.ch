﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//using System.Windows.HierarchicalDataTemplate;

namespace EtudiantsVDLGestion
{
    public partial class AjoutTests : ChildWindow
    {
        public AjoutTests()
        {
            InitializeComponent();

            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.getMetierCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getMetierCompletedEventArgs>(affiche_metier);
            client.getMetierAsync();
        }

        public void cleanGUI()
        {

            myTreeView.DataContext = null;
            myTreeViewTest.DataContext = null;
            cbxModTest.ItemsSource = null;
            cbxGroTest.ItemsSource = null;
            cbxTest.ItemsSource = null;
            stackTest.Visibility = Visibility.Collapsed;


        }

        //affichage metier
        public void affiche_metier(object sender, EtudiantsVDLGestion.ServiceReference1.getMetierCompletedEventArgs e)
        {

            lst_metier = new List<work.metiers>();
            id_metier = -1;
            id_groupe = -1;
            id_module = -1;
            id_questions = -1;

            //réinitialize la GUI
            cleanGUI();



            foreach (var row in e.Result)
            {
                lst_metier.Add(new work.metiers { id_metier = row[0].ToString(), nom_metier = row[1] });

            }

            cbxMetTest.ItemsSource = lst_metier;
            cbxMetTest.DisplayMemberPath = "nom_metier";
            cbxMetTest.SelectionChanged += new SelectionChangedEventHandler(cb_SelectionChanged);
            cbxMetTest.SelectedItem = "Informatique";

        }

        //action declencher lors du changement de metier
        void cb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            selectedCarMet = (work.metiers)cbxMetTest.SelectedItem;
            id_metier = Int32.Parse(selectedCarMet.id_metier);
            cleanGUI();
            //Population des combobox groupe

            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.getGroupeCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getGroupeCompletedEventArgs>(affiche_groupe);
            client.getGroupeAsync(id_metier, false);
        }


        //affichage des groupe
        public void affiche_groupe(object sender, EtudiantsVDLGestion.ServiceReference1.getGroupeCompletedEventArgs e)
        {

            lst_groupe = new List<work.Groupes>();
            cbxModTest.ItemsSource = null;
            cleanGUI();
            //id_metier = -1;

            foreach (var row in e.Result)
            {
                lst_groupe.Add(new work.Groupes { id_groupe = row[0].ToString(), nom_groupe = row[1] });
            }

            cbxGroTest.ItemsSource = lst_groupe;
            cbxGroTest.DisplayMemberPath = "nom_groupe";
            cbxGroTest.SelectionChanged += new SelectionChangedEventHandler(cbGro_SelectionChanged);
            cbxGroTest.SelectedItem = "PDT";
        }


        //construction et affichage du tree des questions du module
        List<work.questionnaire> lstQes = new List<work.questionnaire>();
        public void get_tree(object sender, EtudiantsVDLGestion.ServiceReference1.getQestCompletedEventArgs e)
        {

            lstQes = new List<work.questionnaire>();
            List<work.reponses> lstRep = new List<work.reponses>();
            //row.id_question.ToString(), row.id_reponse.ToString(), row.intitule_que, row.intitule_rep, row.juste 
            int id_current_qes = new int();
            string intitule_qes = string.Empty;
            bool verif = false;
            double point = new double();

            int i = 0;
            foreach (var row in e.Result)
            {
                //verifi ci la lighne du questionnaire et corredte
                if (row[4].ToString().Equals("Y "))
                {
                    verif = true;
                }
                else
                {
                    verif = false;
                }

                //Verifi ci la ligne concerne toujours la meme questionsw  
                //o signifiant le premier tours
                if (((id_current_qes == Int32.Parse(row[0])) || (i == 0)))
                {
                    lstRep.Add(new work.reponses { id_reponse = Int32.Parse(row[1]), intitule_rep = row[3], juste = verif });
                }
                else
                {
                    //insertion de l'objet questionnaire
                    // System.Windows.MessageBox.Show(row[0].ToString() + " " + id_current_qes);
                    lstQes.Add(new work.questionnaire { id_qes = id_current_qes, intitule_qes = intitule_qes, lst_rep = lstRep, nbPoints = point });
                    //Questions suivante
                    //réinitialisations de la list pour les reponses 
                    lstRep = new List<work.reponses>();
                    lstRep.Add(new work.reponses { id_reponse = Int32.Parse(row[1]), intitule_rep = row[3], juste = verif });
                }

                id_current_qes = Int32.Parse(row[0]);
                intitule_qes = row[2].ToString();
                point = Double.Parse(row[5].ToString());
                i++;
            }

            //ajout du dernier questionnaire
            lstQes.Add(new work.questionnaire { id_qes = id_current_qes, intitule_qes = intitule_qes, lst_rep = lstRep, nbPoints = point });
            myTreeView.DataContext = lstQes;


            // System.Windows.MessageBox.Show(selectedCarMod.id_module.ToString());
            //Affichage des test du module (ci exist)
            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.getTestCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getTestCompletedEventArgs>(affiche_test);
            client.getTestAsync(selectedCarMod.id_module);
        }


        //affichage les test du module ci existe
        List<work.tests> lstTest = new List<work.tests>();
        public void affiche_test(object sender, EtudiantsVDLGestion.ServiceReference1.getTestCompletedEventArgs e)
        {

            lstTest = new List<work.tests>();
            //id_metier = -1;

            foreach (var row in e.Result)
            {
                lstTest.Add(new work.tests { id_test = Int32.Parse(row[0].ToString()), nom_tes = row[1], tempsacc = row[2] });
            }

            cbxTest.ItemsSource = lstTest;
            cbxTest.DisplayMemberPath = "nom_tes";
            cbxTest.SelectionChanged += new SelectionChangedEventHandler(cb_SelectionChangedTest);
        }



        //afichage du test 
        public work.tests selectedCarTest = new work.tests();

        //permet d'encapsuler l'id du test
        int id_test = -1;

        void cb_SelectionChangedTest(object sender, SelectionChangedEventArgs e)
        {

            if (cbxTest.SelectedIndex == -1)
            {
                stackTest.Visibility = Visibility.Collapsed;
            }
            else
            {
                //rèinitialise les parametre de la GUI TEST
                txtIntiTest.Text = "";
                NBpointsTot = 0;
                nbPointTest.Content = "";

                // myTreeViewTest.DataContext = null;

                selectedCarTest = (work.tests)cbxTest.SelectedItem;

                stackTest.Visibility = Visibility.Visible;

                //controle qu'ubn t4est soit bien sélectionner 
                if (selectedCarTest != null)
                {
                    id_test = selectedCarTest.id_test;
                    txtIntiTest.Text = selectedCarTest.nom_tes;
                    tempsacc.Text = selectedCarTest.tempsacc;

                    EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                    client.getQestCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getQestCompletedEventArgs>(get_trreTest);
                    client.getQestAsync(id_test, id_module);
                }
            }
        }


        //afichage du test actuelement sélectionner
        //total des pouint su test actuel
        double NBpointsTot = new double();

        public List<work.questionnaire> lstQesTest = new List<work.questionnaire>();
        void get_trreTest(object sender, EtudiantsVDLGestion.ServiceReference1.getQestCompletedEventArgs e)
        {


            lstQesTest = new List<work.questionnaire>();
            List<work.reponses> lstRep = new List<work.reponses>();
            //row.id_question.ToString(), row.id_reponse.ToString(), row.intitule_que, row.intitule_rep, row.juste 
            int id_current_qes = new int();
            string intitule_qes = string.Empty;
            bool verif = false;
            double point = new double();
            NBpointsTot = 0;


            int i = 0;
            foreach (var row in e.Result)
            {
                //verifi ci la lighne du questionnaire et corredte
                if (row[4].ToString().Equals("Y "))
                {
                    verif = true;
                }
                else
                {
                    verif = false;
                }

                //Verifi ci la ligne concerne toujours la meme questionsw  
                //o signifiant le premier tours
                if (((id_current_qes == Int32.Parse(row[0])) || (i == 0)))
                {
                    lstRep.Add(new work.reponses { id_reponse = Int32.Parse(row[1]), intitule_rep = row[3], juste = verif });
                }
                else
                {
                    //insertion de l'objet questionnaire
                    // System.Windows.MessageBox.Show(row[0].ToString() + " " + id_current_qes);
                    lstQesTest.Add(new work.questionnaire { id_qes = id_current_qes, intitule_qes = intitule_qes, lst_rep = lstRep, nbPoints = point });
                    NBpointsTot += point;
                    //Questions suivante
                    //réinitialisations de la list pour les reponses 
                    lstRep = new List<work.reponses>();
                    lstRep.Add(new work.reponses { id_reponse = Int32.Parse(row[1]), intitule_rep = row[3], juste = verif });
                }

                id_current_qes = Int32.Parse(row[0]);
                intitule_qes = row[2].ToString();
                point = Double.Parse(row[5].ToString());
                i++;
            }

            //ajout du dernier questionnaire
            lstQesTest.Add(new work.questionnaire { id_qes = id_current_qes, intitule_qes = intitule_qes, lst_rep = lstRep, nbPoints = point });
            NBpointsTot += point;

            nbPointTest.Content = NBpointsTot.ToString();
            myTreeViewTest.DataContext = lstQesTest;


        }



        //permet d'ajouter un questionnaire au test
        void addQest_click(object sender, RoutedEventArgs e)
        {



        }

        public work.questionnaire selectedCarCurrentTest = new work.questionnaire();

        void RemoveQest_click(object sender, RoutedEventArgs e)
        {

            selectedCarCurrentTest = (work.questionnaire)myTreeViewTest.SelectedItem;

            if (selectedCarCurrentTest != null)
            {
                EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                client.delQestFromTestCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.delQestFromTestCompletedEventArgs>(del_qest);
                client.delQestFromTestAsync(id_test, selectedCarCurrentTest.id_qes);
            }
        }


        public void del_qest(object sender, EtudiantsVDLGestion.ServiceReference1.delQestFromTestCompletedEventArgs e)
        {
            //    System.Windows.MessageBox.Show(id_test.ToString());
            myTreeViewTest.DataContext = null;
            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.getQestCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getQestCompletedEventArgs>(get_trreTest);
            client.getQestAsync(id_test, id_module);

        }

        int id_metier = new int();
        int id_groupe = new int();
        int id_module = new int();
        int id_questions = new int();
        List<work.metiers> lst_metier = new List<work.metiers>();


        work.metiers selectedCarMet = new work.metiers();

        public List<work.Groupes> lst_groupe = new List<work.Groupes>();


        public work.Groupes selectedCar = new work.Groupes();
        //action declencher lors du changement de groupe
        void cbGro_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedCar = (work.Groupes)cbxGroTest.SelectedItem;
            cbxModTest.ItemsSource = null;
            cbxTest.ItemsSource = null;
            // System.Windows.MessageBox.Show(selectedCar.nom_groupe);


            if (cbxTest.SelectedIndex == -1)
            {
                if (selectedCar != null)
                {
                    id_groupe = Int32.Parse(selectedCar.id_groupe);
                    myTreeView.DataContext = null;

                    //Population des combobox groupe
                    EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                    client.getModuleCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getModuleCompletedEventArgs>(affiche_mod);
                    client.getModuleAsync(Int32.Parse(selectedCarMet.id_metier), Int32.Parse(selectedCar.id_groupe), false);
                }
            }
            else
            {

                txtIntiTest.Text = "";
                nbPointTest.Content = "";
                myTreeViewTest.DataContext = null;
                myTreeView.DataContext = null;
                nbPointTest.Content = "";
                tempsacc.Text = "";
                cbxTest.SelectedIndex = -1;
                cbxTest.ItemsSource = null;
                stackTest.Visibility = Visibility.Collapsed;

                if (selectedCar != null)
                {
                    id_groupe = Int32.Parse(selectedCar.id_groupe);

                    //Population des combobox groupe
                    EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                    client.getModuleCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getModuleCompletedEventArgs>(affiche_mod);
                    client.getModuleAsync(Int32.Parse(selectedCarMet.id_metier), Int32.Parse(selectedCar.id_groupe), false);
                }

            }
        }


        //Affichage des modules
        public List<work.modules> lst_mod = new List<work.modules>();
        public void affiche_mod(object sender, EtudiantsVDLGestion.ServiceReference1.getModuleCompletedEventArgs e)
        {
            lst_mod = new List<work.modules>();

            foreach (var row in e.Result)
            {
                lst_mod.Add(new work.modules { id_programme = Int32.Parse(row[0]), id_groupe = Int32.Parse(row[1]), id_module = Int32.Parse(row[2]), nom_mod = row[3] });
            }

            cbxModTest.ItemsSource = lst_mod;
            cbxModTest.DisplayMemberPath = "nom_mod";
            cbxModTest.SelectionChanged += new SelectionChangedEventHandler(cbMod_SelectionChanged);
            //cbxMod.SelectedIndex = 0;
        }

        public work.modules selectedCarMod = new work.modules();
        void cbMod_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedCarMod = (work.modules)cbxModTest.SelectedItem;
            // System.Windows.MessageBox.Show(selectedCar.nom_groupe);

            if (selectedCarMod != null)
            {
                id_module = selectedCarMod.id_module;

                EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                client.getQestCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getQestCompletedEventArgs>(get_tree);
                client.getQestAsync(-1, id_module);

            }
        }



        public work.questionnaire selectedCarTreeAdd = new work.questionnaire();

        int selectedQes = new int();
        public void add_qest(object sender, RoutedEventArgs e)
        {

            //System.Windows.MessageBox.Show(selectedCarTest.id_test.ToString());
            selectedCarTreeAdd = (work.questionnaire)myTreeView.SelectedItem;

            if (selectedCarTreeAdd != null)
            {

                selectedQes = selectedCarTreeAdd.id_qes;



                EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                client.InsertQestToTestCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.InsertQestToTestCompletedEventArgs>(add_qestToTest);
                client.InsertQestToTestAsync(id_test, selectedQes, id_module, selectedCar.nom_groupe, selectedCarMod.nom_mod);

            }

        }



        //insertion ou modifications du tests
        //lecture du formulaire pour l'insertion ou la mise a jour du formulaire
        private void insertQest_Click(object sender, RoutedEventArgs e)
        {

            //soumission du test pour la mise a jour 
            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.SubmitTestCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.SubmitTestCompletedEventArgs>(up_test);
            client.SubmitTestAsync(id_test, txtIntiTest.Text, tempsacc.Text, nbPointTest.Content.ToString());

        }


        public void up_test(object sender, EtudiantsVDLGestion.ServiceReference1.SubmitTestCompletedEventArgs e)
        {
            //réinitialise les parametre de la GUI test
            id_test = -1;

            txtIntiTest.Text = "";
            nbPointTest.Content = "";
            myTreeViewTest.DataContext = null;
            nbPointTest.Content = "";
            tempsacc.Text = "";
            cbxMetTest.IsEnabled = true;
            cbxGroTest.IsEnabled = true;
            cbxModTest.IsEnabled = true;
            cbxTest.IsEnabled = true;
            stackTest.Visibility = Visibility.Collapsed;

            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.getTestCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getTestCompletedEventArgs>(affiche_test);
            client.getTestAsync(selectedCarMod.id_module);


        }


        //insertion du questionnaire 

        public void add_qestToTest(object sender, EtudiantsVDLGestion.ServiceReference1.InsertQestToTestCompletedEventArgs e)
        {

            // System.Windows.MessageBox.Show(e.Result.ToString());
            id_test = e.Result;
            //    System.Windows.MessageBox.Show(id_test.ToString());
            myTreeViewTest.DataContext = null;
            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.getQestCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getQestCompletedEventArgs>(get_trreTest);
            client.getQestAsync(id_test, id_module);

        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        //afichage du test 
        //insertion d'un nouveau test
        public bool newTest = false;
        public composant.ConfirmPopUP advertismentNewTest = new composant.ConfirmPopUP();
        private void addTest_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {

            if (newTest)
            {
                cbxMetTest.IsEnabled = true;
                cbxGroTest.IsEnabled = true;
                cbxModTest.IsEnabled = true;
                cbxTest.IsEnabled = true;
                stackTest.Visibility = Visibility.Collapsed;
                newTest = false;
            }
            else
            {

                //controle qu'un metiers groupe et module soit bien selectionner et les verouille pour la création du test
                if (((cbxMetTest.SelectedIndex != -1) && (cbxGroTest.SelectedIndex != -1) && (cbxModTest.SelectedIndex != -1)))
                {
                    stackTest.Visibility = Visibility.Visible;
                    // réinitialise l'id du test ci sélectioner
                    id_test = -1;

                    txtIntiTest.Text = "";
                    nbPointTest.Content = "";
                    myTreeViewTest.DataContext = null;
                    nbPointTest.Content = "";
                    tempsacc.Text = "";


                    //verouille les checkBox
                    cbxMetTest.IsEnabled = false;
                    cbxGroTest.IsEnabled = false;
                    cbxModTest.IsEnabled = false;
                    cbxTest.IsEnabled = false;
                }
                else
                {
                    advertismentNewTest = new composant.ConfirmPopUP();
                    advertismentNewTest.CancelButton.Visibility = Visibility.Collapsed;
                    advertismentNewTest.lbprompt.Content = "Veuillez sélectionner un metiers un groupe et un module\navant de proceder à la création d'un nouveau test";
                    advertismentNewTest.Show();
                }

                newTest = true;


            }



        }

        private void imgdeltest_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {



        }

        //popup de confirmation pour la supression dfes test
        composant.ConfirmPopUP delWin = new composant.ConfirmPopUP();
        private void imgdeltest_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (selectedCarTest != null)
            {
                delWin = new composant.ConfirmPopUP();
                delWin.lbprompt.Content = "Voulez-vous vraiment supprimer le test \n" + selectedCarTest.nom_tes;
                delWin.Closed += new EventHandler(delTE_Closed);
                delWin.Show();
            }
        }


        public void delTE_Closed(object sender, EventArgs e)
        {

            if (delWin.lbverif.Content.Equals("true"))
            {
                // System.Windows.MessageBox.Show("dfdf");
                EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
                client.DelTestCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.DelTestCompletedEventArgs>(del_test);
                client.DelTestAsync(id_test);
            }
        }

        public void del_test(object sender, EtudiantsVDLGestion.ServiceReference1.DelTestCompletedEventArgs e)
        {
            txtIntiTest.Text = "";
            nbPointTest.Content = "";
            myTreeViewTest.DataContext = null;
            nbPointTest.Content = "";
            tempsacc.Text = "";

            //verouille les checkBox
            cbxMetTest.IsEnabled = true;
            cbxGroTest.IsEnabled = true;
            cbxModTest.IsEnabled = true;
            cbxTest.IsEnabled = true;
            stackTest.Visibility = Visibility.Collapsed;

            //rafraichir les test
            EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient client = new EtudiantsVDLGestion.ServiceReference1.EtudiantsVDLGestionServiceClient();
            client.getTestCompleted += new EventHandler<EtudiantsVDLGestion.ServiceReference1.getTestCompletedEventArgs>(affiche_test);
            client.getTestAsync(selectedCarMod.id_module);


        }


    }
}

