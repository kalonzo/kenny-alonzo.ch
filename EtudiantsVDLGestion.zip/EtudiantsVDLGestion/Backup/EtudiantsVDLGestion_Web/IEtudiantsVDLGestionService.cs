﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace EtudiantsVDLGestion_Web
{
    // REMARQUE : vous pouvez utiliser la commande Renommer du menu Refactoriser pour changer le nom d'interface "IEtudiantsVDLGestionService" à la fois dans le code et le fichier de configuration.
    [ServiceContract]
    public interface IEtudiantsVDLGestionService
    {

        [OperationContract]
        void sendMail(string vdl, string user);

        [OperationContract]
        bool getAuthentif(string userSOI, string userFormatteurEtudiantsVDL, string pwd);

        //ce servifce permet d'identifier ci l'utilisateur et deja authentifié ou  ci son compte a été bloqué
        //encapsule également toute les informations d'identifications 
        [OperationContract]
        List<string> WhoisAuthentif(string userSOI, string userVDL);

        //ce service permet d'authetifié l'utilisateur une fois qu'il c'est authetifié
        [OperationContract]
        bool auth(string userFormatteurEtudiantsVDL);

        //ce service permet de déloguer l'utilisateur une fois qu'il c'est authetifié
        [OperationContract]
        bool delo(int id_formatteurEtudiantsVDL);

        [OperationContract]
        string getUserVDL(int id_formatteurEtudiantsVDL);


        //Construction de la GUI
        //ce service permet de construire l'affichage des groupe en fonction de l'id du metier du groupe actuelement sélectionné par l'etudiant authetifié
        [OperationContract]
        List<roleEtudiantsVDL> getRoles();

        //Constructions des actions 
        [OperationContract]
        List<action> getActions(int id_role);

        //Affichage des etudiants par groupe
        [OperationContract]
        List<string[]> getEtudiants(int id_groupe);

        //permet de oppouler la comb des metiers
        [OperationContract]
        List<string[]> getMetier();

        //Supprime la réponse de la base
        [OperationContract]
        bool delRep(int id_rep);

        //permet de oppouler la comb des groupe
        [OperationContract]
        List<string[]> getGroupe(int id_metier, bool orph);

        //permet de oppouler la comb des groupe
        [OperationContract]
        int InsertetudiantsUser(int id_etudiant, string nom_etu, string prenom_etu, string age_etu, string nom_typ, int id_gro, string userVDL1, string pwd);

        //suppresion de l'etudiants sélectioner
        [OperationContract]
        bool DelEtudiant(int id_etudiant);


        //Gui ajout des groupe
        //permet de selectioner les module concernant le groupe  sélectionner
        [OperationContract]
        List<string[]> getModule(int id_metier, int id_groupe, bool orph);

        //Gui ajout des groupe
        //permet de selectioner les module concernant le groupe  sélectionner
        [OperationContract]
        List<string[]> getQes(int id_mod);

        [OperationContract]
        List<string[]> getRep(int id_qes);

        [OperationContract]
        List<string[]> getReps(int id_mod);

        [OperationContract]
        List<string[]> getRepToAdd(int id_rep);

        [OperationContract]
        bool delrepToQest(int id_qes, int id_rep);

        //Efface la questions
        //retourne
        //1 :dans le cas ou la questions appartien a un test
        [OperationContract]
        bool delQest(int id_qest);


        //ajout de metiers
        [OperationContract]
        bool InsertMetier(string nom_met, int id_met);

        //Insertion du qestionnaire 
        [OperationContract]
        bool InsertQest(int id_mod, int id_qes, string nom_qes, string points, string multiQes, List<string[]> lstrep);

        //suppresion de metiers
        [OperationContract]
        bool delMetier(int id_met);

        //ajout de metiers
        [OperationContract]
        bool InsertGroupe(int id_met, string nom_gro, int id_gro);

        //suppresion de metiers
        [OperationContract]
        bool delGroupe(int id_gro);

        //ajout de metiers
        [OperationContract]
        bool InsertMod(int id_gro, string nom_mod, int id_mod);

        //suppresion de metiers
        [OperationContract]
        bool delMod(int id_mod);

        //selection du questionnaire pour le tes
        [OperationContract]
        List<string[]> getQest(int id_test, int id_mod);


        //selections des test pour le module 
        [OperationContract]
        List<string[]> getTest(int id_mod);

        //Insertion du questionnaire sélectionner dans le test
        //cre le test ci il n'existe pas
        [OperationContract]
        int InsertQestToTest(int id_test, int id_qes, int id_mod, string nom_gro, string nom_mod);

        //Insertion du questionnaire sélectionner dans le test
        [OperationContract]
        bool delQestFromTest(int id_test, int id_qes);


        //Mise a jour du test
        [OperationContract]
        bool SubmitTest(int id_test, string nom_tes, string temps_acc, string nbPoints);

        //Mise a jour du test
        [OperationContract]
        bool DelTest(int id_test);

        //
        [OperationContract]
        List<string[]> getEtuByTest(int id_test, int id_gro);

        //Insertions des droits pour un test donnée
        [OperationContract]
        bool InsertDroits(int id_test, int id_droits, int id_etudiants, bool droitest);

        [OperationContract]
        List<string[]> getTestByEtudiants(int id_etudiants);

    }
}
