﻿/*=====================================================================
  
  This file is part of the Autodesk Vault API Code Samples.

  Copyright (C) Autodesk Inc.  All rights reserved.

THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
=====================================================================*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
//using System.Linq;
using System.Text;
using System.Windows.Forms;

using Autodesk.Connectivity.WebServices;
using VDF = Autodesk.DataManagement.Client.Framework;
using Autodesk.DataManagement.Client.Framework.Vault.Currency.Connections;
using System.Linq;

namespace ChangeItemLifecycle
{
    public partial class MainForm : Form
    {
        private Connection m_conn;
        private Item m_loadedItem;
        // We will collect Property Definitions here
        static VDF.Vault.Currency.Properties.PropertyDefinitionDictionary propDefs;

        public MainForm()
        {
            InitializeComponent();
        }

        private void m_getItemButton_Click(object sender, EventArgs e)
        {
           ClearItemData();

            Item item = m_conn.WebServiceManager.ItemService.GetLatestItemByItemNumber(m_itemNumberTextBox.Text);

            if (item == null || item.Id <= 0)
            {
                MessageBox.Show("Item not found");
                return;
            }

            
            m_loadedItem = item;
            SetItemData();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            m_conn = VDF.Vault.Forms.Library.Login(null);
            if (m_conn == null)
                MessageBox.Show("Invalid login");
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (m_conn != null && m_conn.IsConnected)
                VDF.Vault.Library.ConnectionManager.LogOut(m_conn);
        }

        private void m_changeStateButton_Click(object sender, EventArgs e)
        {
            ItemStateChange();
        }


        private void ClearItemData()
        {
            m_currentStateTextBox.Text = "";
            m_nextStateComboBox.SelectedItem = null;
            m_nextStateComboBox.Items.Clear();
        }

        private void SetItemData()
        {
            if (m_loadedItem == null)
                return;

            if (m_loadedItem.LfCyc == null)
            {
                MessageBox.Show("No lifecycle information found.");
                return;
            }

            // grab information about the lifecycle definition that the item is in
            LfCycDef lifeCycleDef = m_conn.WebServiceManager.LifeCycleService.GetLifeCycleDefinitionsByIds(
                m_loadedItem.LfCyc.LfCycDefId.ToSingleArray()).First();

            // create a map of the states so that we can look them up easily.
            Dictionary<long, LfCycState> stateMap = lifeCycleDef.StateArray.ToDictionary(n => n.Id);

            // display the value of the current state
            m_currentStateTextBox.Text = stateMap[m_loadedItem.LfCycStateId].DispName;

            foreach (LfCycTrans trans in lifeCycleDef.TransArray)
            {
                // figure out the transitions from the current state and add them to the combo box
                if (trans.FromId == m_loadedItem.LfCycStateId)
                {
                    TransItem item = new TransItem(trans, stateMap[trans.ToId]);
                    m_nextStateComboBox.Items.Add(item);
                }
            }
        }

        private void ItemStateChange()
        {
            if (m_loadedItem == null)
            {
                MessageBox.Show("No Item loaded.");
                return;
            }

            TransItem transItem = m_nextStateComboBox.SelectedItem as TransItem;
            if (transItem == null)
            {
                MessageBox.Show("No next state selected.");
                return;
            }

            Item updatedItem = m_conn.WebServiceManager.ItemService.UpdateItemLifeCycleStates(
                m_loadedItem.MasterId.ToSingleArray(), transItem.ToState.Id.ToSingleArray(),
                "state change example").First();

            m_loadedItem = updatedItem;

            ClearItemData();
            SetItemData();
            MessageBox.Show("Operation Complete");
        }
    }

    public class TransItem
    {
        public LfCycTrans Transition { get; private set; }
        public LfCycState ToState { get; private set; }

        public TransItem(LfCycTrans trans, LfCycState toState)
        {
            this.Transition = trans;
            this.ToState = toState;
        }

        public override string ToString()
        {
            return ToState.DispName;
        }
    }
}
