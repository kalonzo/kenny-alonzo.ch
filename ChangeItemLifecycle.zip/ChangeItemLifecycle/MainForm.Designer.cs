﻿namespace ChangeItemLifecycle
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.m_itemNumberTextBox = new System.Windows.Forms.TextBox();
            this.m_getItemButton = new System.Windows.Forms.Button();
            this.m_currentStateTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.m_nextStateComboBox = new System.Windows.Forms.ComboBox();
            this.m_changeStateButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Item Number:";
            // 
            // m_itemNumberTextBox
            // 
            this.m_itemNumberTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_itemNumberTextBox.Location = new System.Drawing.Point(88, 17);
            this.m_itemNumberTextBox.Name = "m_itemNumberTextBox";
            this.m_itemNumberTextBox.Size = new System.Drawing.Size(354, 20);
            this.m_itemNumberTextBox.TabIndex = 1;
            // 
            // m_getItemButton
            // 
            this.m_getItemButton.Location = new System.Drawing.Point(88, 43);
            this.m_getItemButton.Name = "m_getItemButton";
            this.m_getItemButton.Size = new System.Drawing.Size(103, 23);
            this.m_getItemButton.TabIndex = 2;
            this.m_getItemButton.Text = "Get Item";
            this.m_getItemButton.UseVisualStyleBackColor = true;
            this.m_getItemButton.Click += new System.EventHandler(this.m_getItemButton_Click);
            // 
            // m_currentStateTextBox
            // 
            this.m_currentStateTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_currentStateTextBox.Enabled = false;
            this.m_currentStateTextBox.Location = new System.Drawing.Point(88, 97);
            this.m_currentStateTextBox.Name = "m_currentStateTextBox";
            this.m_currentStateTextBox.Size = new System.Drawing.Size(354, 20);
            this.m_currentStateTextBox.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Current State:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 126);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Next State:";
            // 
            // m_nextStateComboBox
            // 
            this.m_nextStateComboBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_nextStateComboBox.FormattingEnabled = true;
            this.m_nextStateComboBox.Location = new System.Drawing.Point(88, 123);
            this.m_nextStateComboBox.Name = "m_nextStateComboBox";
            this.m_nextStateComboBox.Size = new System.Drawing.Size(354, 21);
            this.m_nextStateComboBox.Sorted = true;
            this.m_nextStateComboBox.TabIndex = 6;
            // 
            // m_changeStateButton
            // 
            this.m_changeStateButton.Location = new System.Drawing.Point(88, 150);
            this.m_changeStateButton.Name = "m_changeStateButton";
            this.m_changeStateButton.Size = new System.Drawing.Size(103, 23);
            this.m_changeStateButton.TabIndex = 7;
            this.m_changeStateButton.Text = "Change State";
            this.m_changeStateButton.UseVisualStyleBackColor = true;
            this.m_changeStateButton.Click += new System.EventHandler(this.m_changeStateButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(454, 188);
            this.Controls.Add(this.m_changeStateButton);
            this.Controls.Add(this.m_nextStateComboBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.m_currentStateTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.m_getItemButton);
            this.Controls.Add(this.m_itemNumberTextBox);
            this.Controls.Add(this.label1);
            this.Name = "MainForm";
            this.Text = "Change Item Lifecycle";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox m_itemNumberTextBox;
        private System.Windows.Forms.Button m_getItemButton;
        private System.Windows.Forms.TextBox m_currentStateTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox m_nextStateComboBox;
        private System.Windows.Forms.Button m_changeStateButton;
    }
}

