﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Xml.Linq;

namespace EtudiantsVDL_Web
{
    // REMARQUE : vous pouvez utiliser la commande Renommer du menu Refactoriser pour changer le nom d'interface "IEtudiantsVDLService" à la fois dans le code et le fichier de configuration.
    [ServiceContract]
    public interface IEtudiantsVDLService
    {
        [OperationContract]
        string getJobs();

        [OperationContract]
        List<type_etudiant> getTypeEtu();

        [OperationContract]
        List<etudiant> getEtudiants();

        [OperationContract]
        Boolean getAuthentif(string userSOI, string userVDL, string pwd);

        [OperationContract]
        void sendMail(string vdl, string user);

        //ce servifce permet d'identifier ci l'utilisateur et deja authentifié ou  ci son compte a été bloqué
        //encapsule également toute les informations d'identifications 
        [OperationContract]
        List<string> WhoisAuthentif(string userSOI, string userVDL);

        //ce service permet d'authetifié l'utilisateur une fois qu'il c'est authetifié
        [OperationContract]
        bool auth(string userVDL);

        //ce service permet de déloguer l'utilisateur une fois qu'il c'est authetifié
        [OperationContract]
        Boolean delo(int userVDLid);

        //ce service permet de construire l'affichage des groupe en fonction de l'id du metier du groupe actuelement sélectionné par l'etudiant authetifié
        [OperationContract]
        List<groupe> getGroupe(int id_metier);

        //ce service permet de construire l'affichage des module en fonction de l'id du groupe
        [OperationContract]
        List<string[]> getModule(int id_groupe);

        //get question from test
        [OperationContract]
        List<programme_test> getListQuestion(int id_test);

        //get question from test
        [OperationContract]
        float getNbTot(int id_test);

        //get question from test
        [OperationContract]
        int getChrono(int id_test);

        //Enlever le droits au test de l'etudiants en cours de test
        [OperationContract]
        void setDroitTest(int id_test, int id_etudiant);

        //constructions de la premiere questions
        [OperationContract]
        List<question> getQuestion(int id_question);

        [OperationContract]
        List<string[]> getReponse(int id_question);

        [OperationContract]
        string getUserVDL(int id_etudiants);

        [OperationContract]
        List<string[]> getActifTest(int id_etudiant, int id_groupe);

        //correction de la question en cours de validation
        [OperationContract]
        List<string[]> getCorrection(int id_question);

        //Insertion du resultat
        [OperationContract]
        bool insertResult(int etu, int test, string corriges, string datdebut, string datdefin, string ptOBT, string ptTot, string notes);





        //permet d'aficher les groupes et les section dans un dataset
        // [OperationContract]
        // void getModByGroupe();


    }
}
