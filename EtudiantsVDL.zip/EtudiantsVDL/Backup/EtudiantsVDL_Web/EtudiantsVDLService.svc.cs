﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Net.Mail;
using System.Xml.Linq;

namespace EtudiantsVDL_Web
{
    // REMARQUE : vous pouvez utiliser la commande Renommer du menu Refactoriser pour changer le nom de classe "EtudiantsVDLService" à la fois dans le code, le fichier svc et le fichier de configuration.
    public class EtudiantsVDLService : IEtudiantsVDLService
    {


        public string getJobs()
        {
            string jobs = string.Empty;


            return jobs;

        }


        public List<type_etudiant> getTypeEtu()
        {
            EtudiantsVDLDataContext dc = new EtudiantsVDLDataContext();
            var AllEtu = from e in dc.type_etudiants select e;
            return AllEtu.ToList();
        }

        public List<etudiant> getEtudiants()
        {
            EtudiantsVDLDataContext dc = new EtudiantsVDLDataContext();
            var Etudiants = from cust in dc.etudiants.AsEnumerable()
                            select cust;

            return Etudiants.ToList();
        }

        public List<programme_test> getListQuestion(int id_test)
        { 
        
            EtudiantsVDLDataContext dc = new EtudiantsVDLDataContext();

            var querry = (from p1 in dc.programme_tests
                         where p1.id_test == id_test
                         select p1).ToList();

            return querry.ToList();
        
        }


        public float getNbTot(int id_test)
        {

            float nbTot = new float();

            EtudiantsVDLDataContext dc = new EtudiantsVDLDataContext();

            var totNotations = from pr in dc.programme_tests
                               from qe in dc.questions
                               where pr.id_question == qe.id_question
                               where pr.id_test == id_test
                               select new{qe.nombre_point_que};



            foreach (var row in totNotations)
            {
                nbTot += float.Parse(row.nombre_point_que);
            }
                


            return nbTot;

        }


        public List<question> getQuestion(int id_question)
        {

            EtudiantsVDLDataContext dc = new EtudiantsVDLDataContext();

            var querry = (from q1 in dc.questions
                          where q1.id_question == id_question
                          select q1).ToList();

            return querry.ToList();

        }


        public List<string[]> getReponse(int id_question) {

            List<string[]> lst = new List<string[]>();


            EtudiantsVDLDataContext dc = new EtudiantsVDLDataContext();
            var querry = from questio in dc.questionnaires
                         from que in dc.questions
                         from rep in dc.reponses
                         where questio.id_question == que.id_question
                         where questio.id_reponse == rep.id_reponse
                         where que.id_question == id_question
                         select new { rep.intitule_rep,rep.id_reponse};


            foreach (var row in querry) {
                lst.Add(new string[] { row.intitule_rep, row.id_reponse.ToString() }); 
            }
                
               


            return lst;
        
        }


        //correction de reponse
        public List<string[]> getCorrection(int id_question) {

            List<string[]> lst = new List<string[]>();
            EtudiantsVDLDataContext dc = new EtudiantsVDLDataContext();


            var query = from rep in dc.reponses
                        from qup in dc.questionnaires
                        from que in dc.questions
                        where rep.id_reponse == qup.id_reponse
                        where que.id_question == qup.id_question
                        where que.id_question == id_question
                        select new {rep.id_reponse, qup.juste};

            foreach(var row in query){

                lst.Add(new string[]{row.id_reponse.ToString(),row.juste});
            
            }
            return lst;
        }



        public List<string[]> getActifTest(int id_etudiant, int id_groupe) {

            List<string[]> lst = new List<string[]>();


            EtudiantsVDLDataContext dc = new EtudiantsVDLDataContext();
            var Groupe = (from te in dc.tests
                          from pt in dc.programme_tests
                          from qe in dc.questions
                          from mo in dc.modules
                          from go in dc.groupes
                          from pr in dc.programmes
                          from et in dc.etudiants
                          where te.id_test == pt.id_test
                          where qe.id_question == pt.id_question
                          where mo.id_module == qe.id_module
                          where go.id_groupe == pr.id_groupe
                          where mo.id_module == pr.id_module
                          where et.id_groupe == go.id_groupe
                          where et.id_etudiant == id_etudiant
                          where go.id_groupe == id_groupe
                          select new { te.id_test,mo.id_module, mo.nom_mod,te.nom_tes}).Distinct();

            foreach(var row in Groupe){

                lst.Add(new string[]{row.id_test.ToString(),row.id_module.ToString(),row.nom_mod,row.nom_tes});

            }

            return lst;
        }

        public List<groupe> getGroupe(int id_metier)
        {
            EtudiantsVDLDataContext dc = new EtudiantsVDLDataContext();
            var Groupe = from cust in dc.groupes.AsEnumerable()
                            where cust.id_metier == id_metier
                            select cust;

            return Groupe.ToList();
        }

        public List<string[]> getModule(int id_groupe)
        {

            List<string[]> plop = new List<string[]>();

            EtudiantsVDLDataContext dc = new EtudiantsVDLDataContext();
            var Etudiants = from mod in dc.modules
                            from pro in dc.programmes
                            from gro in dc.groupes
                            where mod.id_module == pro.id_module
                            where gro.id_groupe == pro.id_groupe
                            where gro.id_groupe == id_groupe
                            select new { mod.nom_mod, mod.id_module };

            foreach (var row in Etudiants) { 
                
                plop.Add(new string[]{row.nom_mod.ToString(),row.id_module.ToString()});
            }

            return plop;
        }



        //methode permettant de controler ci l'etudiant c'est deja loguer dans la journées
        public List<string> WhoisAuthentif(string userSOI, string userVDL)
        {

            //Boolean verif = false;
            List<string> lst = new List<string>();

            EtudiantsVDLDataContext dc = new EtudiantsVDLDataContext();
            //string userVDL = "";
            int id = -1;
            int idTest = -1;
            string nom_test = string.Empty;
            string auth = string.Empty;
            string bann = string.Empty;
            int userVDL_id = -1;
            int id_groupe = -1;
            string metier = string.Empty;
            int id_metier = -1;
            int id_userVDL = -1;
            string nom = string.Empty;
            string prenom = string.Empty;

            if (userVDL == null){
                userVDL = "";
            }


            if (userVDL.Equals(""))
            {
                var authentif = from e1 in dc.userVDLs
                                join e2 in dc.etudiants
                                on e1.id_etudiant equals e2.id_etudiant
                                where e1.userSOI.Equals(userSOI.ToUpper())
                                select new { e1.userVDL1, e1.auth, e1.bann, e2.id_etudiant, e1.userVDL_id, e2.id_groupe,e2.nom_etu, e2.prenom_etu };

                foreach (var rown in authentif) { userVDL = rown.userVDL1; id = rown.id_etudiant; auth = rown.auth; bann = rown.bann; userVDL_id = rown.userVDL_id; id_groupe = rown.id_groupe; userVDL_id = rown.userVDL_id; nom = rown.nom_etu; prenom = rown.prenom_etu; }
            }
            else { 
                            var authentif = from e1 in dc.userVDLs
                            join e2 in dc.etudiants
                            on e1.id_etudiant equals e2.id_etudiant
                            where e1.userSOI.Equals(userSOI.ToUpper())
                            where e1.userVDL1.Equals(userVDL)
                                            select new { e1.userVDL1, e1.auth, e1.bann, e2.id_etudiant, e1.userVDL_id, e2.id_groupe, e2.nom_etu, e2.prenom_etu };

                            foreach (var rown in authentif) { userVDL = rown.userVDL1; id = rown.id_etudiant; auth = rown.auth; bann = rown.bann; userVDL_id = rown.userVDL_id; id_groupe = rown.id_groupe; userVDL_id = rown.userVDL_id; nom = rown.nom_etu; prenom = rown.prenom_etu; }
            }

            //permet de retrouver l'utilisateur 
            

            if (!userVDL.Equals(""))
            {

                var query = from t1 in dc.droits_tests
                            from e1 in dc.etudiants
                            where t1.id_etudiant == e1.id_etudiant
                            where t1.droitE.Equals('Y')
                            where e1.id_etudiant == id
                            select new { t1.id_test };


                foreach (var row in query) { idTest = row.id_test; }


                var queryMetiers = from g1 in dc.groupes
                                   from m1 in dc.metiers
                                   where g1.id_metier == m1.id_metier
                                   where g1.id_groupe == id_groupe
                                   select new { m1.nom_metier, m1.id_metier };

                foreach (var row in queryMetiers) { metier = row.nom_metier; id_metier = row.id_metier; };


                var nomTest = from t1 in dc.tests
                              where t1.id_test == idTest
                              select new { t1.nom_tes };

                foreach (var row in nomTest) { nom_test = row.nom_tes;  };

                lst.Add(id.ToString());
                lst.Add(idTest.ToString());
                lst.Add(nom_test.ToString());
                lst.Add(userSOI);
                lst.Add(userVDL);
                lst.Add(auth);
                lst.Add(bann);
                lst.Add(userVDL_id.ToString());
                lst.Add(id_groupe.ToString());
                lst.Add(metier);
                lst.Add(id_metier.ToString());
                lst.Add(id_userVDL.ToString());
                lst.Add(nom);
                lst.Add(prenom);

            }

            return lst;

        }


        //permet d'identifié l'utilisateur lors du login
        public Boolean getAuthentif(string userSOI, string userVDL, string pwd)
        {

            Boolean verif = false;

            EtudiantsVDLDataContext dc = new EtudiantsVDLDataContext();

            var authentif = from e1 in dc.userVDLs
                            join e2 in dc.etudiants
                            on e1.id_etudiant equals e2.id_etudiant
                            where e1.userVDL1.Equals(userVDL)
                            where e1.userSOI.Equals(userSOI)
                            select new { e1.userVDL1, e1.userSOI };

            string pwdDB = string.Empty;
            var test = dc.decryptPWD(pwd);

            foreach (var row in test)
            {
                if (row.userVDL != "N")
                {
                    foreach (var row2 in authentif)
                    {
                        if (row2.userSOI.Equals(userSOI))
                        {
                            if (row2.userVDL1.Equals(userVDL))
                            {
                                verif = true;
                            }
                        }
                    }
                }
            }

            return verif;

        }

        //authentifi l'utilisateur lors de la prochaine connexions
        public bool auth(string userVDL)
        {
            bool auth = false;
            if (userVDL != "")
            {
                EtudiantsVDLDataContext dc = new EtudiantsVDLDataContext();
            var authentif = (from c in dc.userVDLs
                             where c.userVDL1.Equals(userVDL)
                             select c).First();

            authentif.auth = "Y";
            dc.SubmitChanges();
            auth = true;

            }


            return auth;
            
        }

        //get question from test
        public int getChrono(int id_test){

            int i = 0;

            EtudiantsVDLDataContext dc = new EtudiantsVDLDataContext();
            var authentif = from tim in dc.tests
                            where tim.id_test == id_test
                            select new {tim.temps_accorde_tes};

            foreach (var row in authentif) {
                i = Int32.Parse(row.temps_accorde_tes);
            }

            return i;
        
        }

        //get question from test
        //appeler au debut du test pour réenitialiser les droits du test en cours
        public void setDroitTest(int id_test, int id_etudiant )
        {

            EtudiantsVDLDataContext dc = new EtudiantsVDLDataContext();
            var authentif = (from c in dc.tests
                             from dr in dc.droits_tests
                             from et in dc.etudiants
                             where c.id_test == dr.id_test
                             where et.id_etudiant == dr.id_etudiant
                             where et.id_etudiant == id_etudiant
                             where c.id_test == id_test
                             select dr).First();

            authentif.droitE = "N";
            dc.SubmitChanges();

          

        }
        
        //Insertion du resultat
        public bool insertResult(int etu, int test,string corriges,string datdebut,string datdefin,string ptOBT, string ptTot,string notes ) {
            bool verif = true;

            EtudiantsVDLDataContext dc = new EtudiantsVDLDataContext();
            int resultat = new int();
            var resu = from tes in dc.tests
                       from resul in dc.resultats
                       from etud in dc.etudiants
                       from dro in dc.droits_tests
                       where resul.id_test == tes.id_test
                       where dro.id_test == tes.id_test
                       where dro.id_etudiant == etud.id_etudiant
                       where tes.id_test == test
                       where etud.id_etudiant == etu
                       select resul;

            if (resu.Count() != 0)
            {
                foreach(var row in resu){
                    row.id_test = test;
                    row.corrige = corriges;
                    row.date_debut = datdebut;
                    row.date_fin = datdefin;
                    row.nombre_pointOBT_res = ptOBT;
                    row.nombre_pointMAX_max_res = ptTot;
                    row.note = notes;
                }
                dc.SubmitChanges();
            }
            else
            {
                //le type d'etudiants n'existe pas et doit etre crée
                resultat endup = new resultat
                {
                    id_test = test,
                    corrige = corriges,
                    date_debut = datdebut,
                    date_fin = datdefin,
                    nombre_pointOBT_res = ptOBT,
                    nombre_pointMAX_max_res = ptTot,
                    note = notes
                };

                dc.resultats.InsertOnSubmit(endup);
                dc.SubmitChanges();
                resultat = endup.id_resultat;
            }
                //creation du datacontexte pour l'insertion du nouveau type d'etudiants
               // EtudiantsVDLDataContext dcTy = new EtudiantsVDLDataContext();
            //insertion du resultats dans le portfolio
            portfolio port = new portfolio
            {
                id_etudiant = etu,
                date_res = datdebut,
                id_resultat = resultat
            };

            dc.portfolios.InsertOnSubmit(port);
            dc.SubmitChanges();

            return verif;
        }


        //Dé logue lutilisateurs du site
        public Boolean delo(int userVDLid)
        {

            Boolean quit = true;
            EtudiantsVDLDataContext dc = new EtudiantsVDLDataContext();
            var authentif = (from c in dc.userVDLs
                             where c.userVDL_id == userVDLid
                             select c).First();

            authentif.auth = "N";
            dc.SubmitChanges();

            return quit;

        }


       public string getUserVDL(int id_etudiants) {
            
            string str = string.Empty;

            EtudiantsVDLDataContext dc = new EtudiantsVDLDataContext();
            var authentif = from user in dc.userVDLs
                            join e1 in dc.etudiants
                            on user.id_etudiant equals e1.id_etudiant
                            where e1.id_etudiant == id_etudiants
                            select new {user.userVDL1};


            foreach(var row in authentif){
                str = row.userVDL1;
            }

            return str;
        }



        //service permettant d'envoyer un mail lors de trois echecs d'inscription
        public void sendMail(string vdl, string user)
        {



            string fromEmail = "kenny.alonzo@lausanne.ch";//This field will contain the FROM email 
            string ToEmail = "kenny.alonzo@lausanne.ch";//This field will contain destination email             
            string body = "Hello"; //This field will contain the body of the email 
            string subject = "Test"; //This field will contain the subject 


            SmtpClient MyMail = new SmtpClient("https://owa.lausanne.ch/owa/");//exchange or smtp server goes here. 
            //MyMail.DeliveryMethod = SmtpDeliveryMethod.Network;
            //MyMail.UseDefaultCredentials = true;
            //MyMail.ClientCertificates = "";
            // MyMail.Send(fromEmail, ToEmail, subject, body);




            /* MailMessage mail = new MailMessage();
             SmtpClient SmtpServer = new SmtpClient("LSNXCH40.lausanne.ch");

             mail.From = new MailAddress("kenny.alonzo@lausanne.ch");
             mail.To.Add("kenny.alonzo@lausanne.ch");
             mail.Subject = "This is for testing SMTP mail from GMAIL";
             mail.Body = "Le compte " + vdl + " à été bloqué par l'utilisateurs" + user;

            // SmtpServer.Port = 587;
             SmtpServer.UseDefaultCredentials = true;
             SmtpServer.Credentials = new System.Net.NetworkCredential();
             //SmtpServer.EnableSsl = true;

             SmtpServer.Send(mail);
             */

        }
    }
}
