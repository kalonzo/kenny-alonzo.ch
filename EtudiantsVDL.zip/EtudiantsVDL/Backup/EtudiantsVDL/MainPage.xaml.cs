﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Browser;
using System.Xml;
using System.Text;
using System.ComponentModel;
using System.Windows.Threading;


//using System.Math;

namespace EtudiantsVDL
{
    public partial class MainPage : UserControl
    {


        public MainPage()
        {
            InitializeComponent();
            Loaded += new RoutedEventHandler(Page_Loaded);
        }


        string userloc = "LOCAL";
        //authentification de la personne connecté l'utilisateur
        void Page_Loaded(object sender, RoutedEventArgs e)
        {


            string UserAccount = App.UserID;
            string[] str = UserAccount.Split('\\');

            EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient client = new EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient();
            client.WhoisAuthentifCompleted += new EventHandler<EtudiantsVDL.ServiceReference1.WhoisAuthentifCompletedEventArgs>(read_user);
            client.WhoisAuthentifAsync(userloc, getCookie("test"));


        }


        /////////////////////////////////////////////Module authentification


        //variable pour la carte d'identité de l'etudiants
        public int id_etudiant = new int();
        public int id_test = new int();
        public string nom_test = string.Empty;
        public string userSOI = string.Empty;
        public string userVDL = string.Empty;
        //definit si l'utilisateur est deja authetifie
        public bool auth = false;
        //le compte pour ce crefentiel est bloqué
        public bool bann = false;
        public int userVDLid = new int();
        public int id_groupe = new int();
        public string metier = string.Empty;
        public int id_metier = new int();

        //A true une fois l'utilisateur authentifié
        public bool authetif = false;
        public LogIN winLog = new LogIN();

        //ecriture lecture d'uncookie
        private bool setCookie(string key, string value)
        {
            if (string.IsNullOrEmpty(key) || string.IsNullOrEmpty(value))
            { return false; }
            DateTime dt = DateTime.Now + TimeSpan.FromDays(1);
            string s = key.Trim() + "=" + value.Trim()
                + ";expires=" + dt.ToString("R");
            HtmlPage.Document.SetProperty("cookie", s);
            return true;
        }



        private string getCookie(string key)
        {
            string[] cookies = HtmlPage.Document.Cookies.Split(';');
            foreach (string cookie in cookies)
            {
                string[] pair = cookie.Split('=');
                if (pair.Length == 2)
                {
                    if (pair[0].ToString() == key)
                        return pair[1];
                }
            }
            return null;
        }


        private void logOut_Click(object sender, RoutedEventArgs e)
        {
            EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient client = new EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient();
            client.deloCompleted += new EventHandler<EtudiantsVDL.ServiceReference1.deloCompletedEventArgs>(closeApp);
            client.deloAsync(userVDLid);

            // HtmlPage.Window.Invoke("CloseWindow");
        }

        private void closeApp(object sender, EtudiantsVDL.ServiceReference1.deloCompletedEventArgs e)
        {

            setCookie("test", "");
            HtmlPage.Window.Invoke("CloseWindow");

        }


        //permet de lire l'identité de l'utilisateur lors de l'inscription
        void read_user(object sender, EtudiantsVDL.ServiceReference1.WhoisAuthentifCompletedEventArgs e)
        {

            id_etudiant = Int32.Parse(e.Result[0]);
            id_test = Int32.Parse(e.Result[1]);
            nom_test = e.Result[2];
            userSOI = e.Result[3];

            if (e.Result[5].Equals("Y "))
            {
                auth = true;
            }

            if (e.Result[6].Equals("Y "))
            {

                bann = true;
            }
            userVDLid = Int32.Parse(e.Result[7]);
            id_groupe = Int32.Parse(e.Result[8]);
            metier = e.Result[9];
            id_metier = Int32.Parse(e.Result[10]);

            lbAsset.Content = e.Result[12] + " "+e.Result[13];
            lbUser.Content = getCookie("test");
            lbmetier.Content = metier;

            // System.Windows.MessageBox.Show();

            //affichage de la fenetre de LogIN     
            if (!auth)
            {
                winLog.Closed += new EventHandler(PopupWindow_Closed);
                winLog.Show();
            }
            else
            {
                //Chargement des groupes

                EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient client1 = new EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient();
                client1.getGroupeCompleted += new EventHandler<EtudiantsVDL.ServiceReference1.getGroupeCompletedEventArgs>(load_job);
                client1.getGroupeAsync(id_metier);
            }

        }

        //evenement qui ce declenche lors de la fermeture de la fenetre LogIN
        private void PopupWindow_Closed(object sender, EventArgs e)
        {


            userSOI = winLog.lbuserSOI.Content.ToString();
            userVDL = winLog.lbVDL.Content.ToString();
            setCookie("test", userVDL);
            EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient client5 = new EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient();
            client5.authCompleted += new EventHandler<EtudiantsVDL.ServiceReference1.authCompletedEventArgs>(connect_user);
            client5.authAsync(userVDL);

        }

        public void connect_user(object sender, EtudiantsVDL.ServiceReference1.authCompletedEventArgs e)
        {


            EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient client = new EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient();
            client.WhoisAuthentifCompleted += new EventHandler<EtudiantsVDL.ServiceReference1.WhoisAuthentifCompletedEventArgs>(read_user);
            client.WhoisAuthentifAsync(userloc, userVDL);

        
        }


        /////////////////////////Module sélectionner

        public int selectedStack = new int();


        //liste d'objet contenant les groupes de travail à afficher
        public List<Button> btn = new List<Button>();
        //list de bouton pour l'affichage des modules
        public List<Button> btnMod = new List<Button>();

        public List<StackPanel> stack = new List<StackPanel>();


        //Construit des groupes
        void load_job(object sender, EtudiantsVDL.ServiceReference1.getGroupeCompletedEventArgs e)
        {

            int i = 0;
            int y = 1;

            //eface la precedente configuration
            stackGroupe.Children.Clear();
            stackstack.Children.Clear();

            //Construction des boutons
            while (i < e.Result.Count)
            {
                //ajout du bouton
                btn.Add(new Button());
                btn[i].Name = e.Result[i].id_groupe.ToString();
                btn[i].Content = e.Result[i].nom_gro;
                btn[i].Margin = new System.Windows.Thickness(20);
                btn[i].VerticalAlignment = VerticalAlignment.Bottom;
                btn[i].Height = 20 * y;

                if (id_test == -1)
                {
                    btn[i].Background = new SolidColorBrush(Colors.Black);
                    btn[i].BorderBrush = new SolidColorBrush(Colors.Black);
                    btn[i].Foreground = new SolidColorBrush(Colors.Black);
                    btn[i].IsEnabled = false;


                }
                else
                {


                    if (e.Result[i].id_groupe == id_groupe)
                    {
                        btn[i].Background = new SolidColorBrush(Colors.Red);
                        btn[i].BorderBrush = new SolidColorBrush(Colors.Red);
                        btn[i].Foreground = new SolidColorBrush(Colors.Red);
                        btn[i].Click += new RoutedEventHandler(Onb2Click);
                    }
                    else
                    {
                        btn[i].Background = new SolidColorBrush(Colors.Black);
                        btn[i].BorderBrush = new SolidColorBrush(Colors.Black);
                        btn[i].Foreground = new SolidColorBrush(Colors.Black);
                        btn[i].IsEnabled = false;

                    }

                }



                //ajout du stack pannel en dessou du bouton afin d'acceulir les modules
                stack.Add(new StackPanel());
                stack[i].Name = e.Result[i].nom_gro;
                stack[i].Margin = new System.Windows.Thickness(40);
                stack[i].Orientation = Orientation.Horizontal;
                //stack[i].Orientation = Orientation.Vertical;
                // stack[i].Height = 30;
                // stack[i].Width = 70;


                // Orientation="Horizontal" HorizontalAlignment="Center";


                //ajoute le composant à l'application
                stackGroupe.Children.Add(btn[i]);
                stackstack.Children.Add(stack[i]);
                i++;
                y++;
            }


            EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient client = new EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient();
            client.getActifTestCompleted += new EventHandler<EtudiantsVDL.ServiceReference1.getActifTestCompletedEventArgs>(getActifTest);
            client.getActifTestAsync(id_etudiant, id_groupe);

        }

        //permet de détecter le bouton clicker et de rediriger l'evenement
        void Onb2Click(object sender, RoutedEventArgs e)
        {

            int i = 0;

            foreach (StackPanel pan in stack) { pan.Children.Clear(); };


            while (i < btn.Count)
            {
                if (btn[i].IsPressed)
                {
                    //stock temporairement l'indice tu tableau pour l'ajout des module
                    selectedStack = i;
                    EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient client = new EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient();
                    client.getModuleCompleted += new EventHandler<EtudiantsVDL.ServiceReference1.getModuleCompletedEventArgs>(load_mods);
                    client.getModuleAsync(Int32.Parse(btn[i].Name));
                }

                i++;
            }

        }

        //construction du tableau des test par groupe (nécessaire au bon fonctionnement de l'applicatoion)
        List<string[]> ActifTest = new List<string[]>();

        void getActifTest(object sender, EtudiantsVDL.ServiceReference1.getActifTestCompletedEventArgs e)
        {


            foreach (var row in e.Result)
            {

                ActifTest.Add(new string[] { row[0], row[1], row[2], row[3] });
                // System.Windows.MessageBox.Show(row[0].ToString()+ row[1].ToString());
            }
        }


        void load_mods(object sender, EtudiantsVDL.ServiceReference1.getModuleCompletedEventArgs e)
        {

            int i = 0;
            int y = 1;
            int d = 0;
            int plop = 0;
            bool btnCreate = false;

            btnMod.Clear();
            stack[selectedStack].Children.Clear();

            //Construction des boutons
            while (i < e.Result.Count)
            {
                //ajout du bouton
                btnMod.Add(new Button());
                // btnMod[i].Name = e.Result[i][1];
                btnMod[i].Content = e.Result[i][0];
                //btnMod[i].Name = "dd";
                btnMod[i].Margin = new System.Windows.Thickness(20);
                btnMod[i].VerticalAlignment = VerticalAlignment.Bottom;
                btnMod[i].Height = 20 * y;

                plop = 0;
                btnCreate = false;
                while (plop < ActifTest.Count)
                {

                    if (ActifTest[plop][1].Equals(e.Result[i][1]))
                    {
                        //btnMod[i].Name = (ActifTest[plop][0]).ToString();
                        btnMod[i].Background = new SolidColorBrush(Colors.Red);
                        btnMod[i].BorderBrush = new SolidColorBrush(Colors.Red);
                        btnMod[i].Foreground = new SolidColorBrush(Colors.Red);
                        btnMod[i].Click += new RoutedEventHandler(clickFin);
                        btnCreate = true;
                    }

                    plop++;
                }


                if (btnCreate == false)
                {
                    btnMod[i].Background = new SolidColorBrush(Colors.Black);
                    btnMod[i].BorderBrush = new SolidColorBrush(Colors.Black);
                    btnMod[i].Foreground = new SolidColorBrush(Colors.Black);
                    btnMod[i].IsEnabled = false; ;
                }


                i++;
                y++;
            }

            d = 0;
            while (d < btnMod.Count)
            {

                stack[selectedStack].Children.Add(btnMod[d]);
                d++;
            }

        }


        void clickFin(object sender, RoutedEventArgs e)
        {

            int i = 0;
            int y = 0;

            while (i < btnMod.Count)
            {
                if (btnMod[i].IsPressed)
                {
                    stkselect.Visibility = System.Windows.Visibility.Collapsed;

                    tabSelect.Visibility = System.Windows.Visibility.Collapsed;
                    tabSelect.IsEnabled = false;
                    tabSelect.IsSelected = false;

                    tabTest.IsEnabled = true;
                    tabTest.IsSelected = true;
                    //debut de la construction du test
                    //stockage des question

                    y = 0;
                    while (y < ActifTest.Count)
                    {
                        if (btnMod[i].Content.ToString().Equals(ActifTest[y][2]))
                        {
                            id_test = Int32.Parse(ActifTest[y][0]);
                            nom_test = ActifTest[y][3];
                            EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient client = new EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient();
                            client.getListQuestionCompleted += new EventHandler<EtudiantsVDL.ServiceReference1.getListQuestionCompletedEventArgs>(step_test);
                            client.getListQuestionAsync(id_test);
                        }
                        y++;
                    }
                }
                i++;
            }
        }


        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {


        }


        /////////////////////////////////////////////Module Tester


        //indique quand le test est fini
        bool testFin = false;

        Storyboard _gameLoop = new Storyboard();
        public TimeSpan chrono40 = new TimeSpan();
        public TimeSpan chronotop = new TimeSpan(0, 0, 0);
        public string datedebutest = string.Empty;
        public string datefinest = string.Empty;
   
        int count = 0;


        
        // variable pour por le traitement du résultat
        //Calcule de la moyenne en fonction du nombre de poit total
        //(nbObt * (6:nbTot))
        //nombre de point total
        public double nbTot = new float();
        public double nbObt = new float();
        public double NoteMax = 6.0;
        public double NoteObt = 6.0;
        public double resultats = new double();


               void MainGameLoop(object sender, EventArgs e) {
                   // Add any game logic/animation here.           
                   // Example:            
                   chrono.Content = chrono40.ToString();
                   chrono40 = chrono40 - new TimeSpan(0, 0, 1);
                   count++;


                   if (chrono40 == chronotop)
                   {
                       endTest();

                   }

                   // Continue storyboard timer 
                   _gameLoop.Begin();        
               }


        private void step_test(object sender, EtudiantsVDL.ServiceReference1.getListQuestionCompletedEventArgs e)
        {


            foreach (var plop in e.Result)
            {
                lstQuestions.Add(Int32.Parse(plop.id_question.ToString()));
                IndexMax++;
                //System.Windows.MessageBox.Show(plop.id_question.ToString());

            }

            //Preparation de l'affichage pour la premiere question
            lbtest.Content = nom_test;


            //calcule du nombre de point total pour le test

            EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient client = new EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient();
            client.getChronoCompleted += new EventHandler<EtudiantsVDL.ServiceReference1.getChronoCompletedEventArgs>(construct_test);
            client.getChronoAsync(id_test);


        }


        public void construct_test (object sender, EtudiantsVDL.ServiceReference1.getChronoCompletedEventArgs e )
        {


            int temps_accorde = e.Result;


            EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient client3 = new EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient();
            //client.getChronoCompleted += new EventHandler<EtudiantsVDL.ServiceReference1.getChronoCompletedEventArgs>(construct_test);
            client3.setDroitTestAsync(id_test,id_etudiant);


            //initialisation du chronometre
            chrono40 = new TimeSpan(0, temps_accorde, 0);
            //représente la vitesse à laquelle le chronometre s'ecoule
            _gameLoop.Duration = TimeSpan.FromSeconds(1);
            _gameLoop.Completed += new EventHandler(MainGameLoop);
            _gameLoop.Begin();
            datedebutest = DateTime.Now.ToString();

            EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient client = new EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient();
            client.getNbTotCompleted += new EventHandler<EtudiantsVDL.ServiceReference1.getNbTotCompletedEventArgs>(first_move);
            client.getNbTotAsync(id_test);
    
    
        }


        public void first_move(object sender, EtudiantsVDL.ServiceReference1.getNbTotCompletedEventArgs e){
        
        
            nbTot = e.Result;

           // System.Windows.MessageBox.Show(nbTot.ToString());

            EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient client = new EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient();
            client.getQuestionCompleted += new EventHandler<EtudiantsVDL.ServiceReference1.getQuestionCompletedEventArgs>(build_questions);
            client.getQuestionAsync((lstQuestions[IndexQuestions]));

            // HtmlPage.Window.Invoke("CloseWindow");
        
        }

        double pointCourant = new double();

        public List<int> lstQuestions = new List<int>();
        public int IndexQuestions = 0;
        public int IndexMax = 1;
        List<CheckBox> checkRep = new List<CheckBox>();
        List<RadioButton> checkrd = new List<RadioButton>();
        List<string[]> lstRep = new List<string[]>();
        public bool ismultip = false;


        //Construction de la première questions
        public void build_questions(object sender, EtudiantsVDL.ServiceReference1.getQuestionCompletedEventArgs e)
        {
            ////////
            NRQuestion.Content = "Q. " + (IndexQuestions + 1).ToString() + " :";
            foreach (var row in e.Result)
            {
                if (row.multiQes.Equals("Y "))
                {
                    ismultip = true;
                }
                else {
                    ismultip = false;
                }
                pointCourant = double.Parse(row.nombre_point_que);
                nbpointQuestion.Content = "(" + row.nombre_point_que + ") points";
                lbnomquestion.Content = row.intitule_que + " ???";
            }
            EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient client = new EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient();
            client.getReponseCompleted += new EventHandler<EtudiantsVDL.ServiceReference1.getReponseCompletedEventArgs>(build_reponse);
            client.getReponseAsync((lstQuestions[IndexQuestions]));
        }



        public void build_reponse(object sender, EtudiantsVDL.ServiceReference1.getReponseCompletedEventArgs e)
        {

            lstRep = new List<string[]>();

            foreach (var row in e.Result)
            {

                lstRep.Add(new string[] { row[0], row[1] });

            }

            checkRep = new List<CheckBox>();
            List<StackPanel> stackRep = new List<StackPanel>();
            checkrd = new List<RadioButton>();
            
            int i = 0;

            foreach (var row in lstRep)
            {


           if (ismultip)
            {
                
                checkRep.Add(new CheckBox());
                checkRep[i].Margin = new System.Windows.Thickness(109, 0, 0, 20);
                checkRep[i].Content = lstRep[i][0];
                checkRep[i].Name = lstRep[i][1];
            }
            else {
                checkrd.Add(new RadioButton());
                checkrd[i].Margin = new System.Windows.Thickness(109, 0, 0, 20);
                checkrd[i].Content = lstRep[i][0];
                checkrd[i].GroupName = "reponses";
                checkrd[i].Name = lstRep[i][1];
            }

                stackRep.Add(new StackPanel());
                stackRep[i].HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                stackRep[i].VerticalAlignment = System.Windows.VerticalAlignment.Stretch;
                stackRep[i].Orientation = Orientation.Horizontal;


                if (ismultip) { stackRep[i].Children.Add(checkRep[i]); } else { stackRep[i].Children.Add(checkrd[i]); }
                

                stckrep.Children.Add(stackRep[i]);

                i++;
            };

        }


        //questions suivante
        public void nextQuestion(object sender, RoutedEventArgs e)
        {

            try
            {
                IndexQuestions++;
                stckrep.Children.Clear();
                EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient client = new EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient();
                client.getQuestionCompleted += new EventHandler<EtudiantsVDL.ServiceReference1.getQuestionCompletedEventArgs>(build_questions);
                client.getQuestionAsync((lstQuestions[IndexQuestions]));
            }
            catch (Exception f)
            {
                IndexQuestions--;
                stckrep.Children.Clear();
                EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient client = new EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient();
                client.getQuestionCompleted += new EventHandler<EtudiantsVDL.ServiceReference1.getQuestionCompletedEventArgs>(build_questions);
                client.getQuestionAsync((lstQuestions[IndexQuestions]));
            }

        }

        public void prevQuestion(object sender, RoutedEventArgs e)
        {

            try
            {
                IndexQuestions--;
                stckrep.Children.Clear();
                EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient client = new EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient();
                client.getQuestionCompleted += new EventHandler<EtudiantsVDL.ServiceReference1.getQuestionCompletedEventArgs>(build_questions);
                client.getQuestionAsync((lstQuestions[IndexQuestions]));
            }
            catch (Exception f)
            {
                IndexQuestions++;
                stckrep.Children.Clear();
                EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient client = new EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient();
                client.getQuestionCompleted += new EventHandler<EtudiantsVDL.ServiceReference1.getQuestionCompletedEventArgs>(build_questions);
                client.getQuestionAsync((lstQuestions[IndexQuestions]));

            }

        }

        public int questionsvalid = 0;
        //chaine de caractere pour le corriger
        public string corriger = string.Empty;
        //Correction des questions
        public void correctQu(object sender, RoutedEventArgs e)
        {
            string plop1 = lstQuestions[IndexQuestions].ToString() + ",";
            int cntREP = 0;

            //Construction du corriger
            if(ismultip){
                foreach (var plop in checkRep)
                {
                   // System.Windows.MessageBox.Show(plop.Name);
                    if ((bool)plop.IsChecked)
                    {
                        if (cntREP >= 1)
                        {
                            plop1 += "," + plop.Name.ToString();
                        }
                        else
                        {
                            plop1 += plop.Name.ToString();
                        }
                    }
                    cntREP++;
                }
            }
            else{
                foreach (var plop in checkrd)
                {
                   // System.Windows.MessageBox.Show(plop.Name);
                    if ((bool)plop.IsChecked)
                    {
                        plop1 += plop.Name.ToString();
                    }

                    cntREP++;
                }
            }
        
                plop1 += ";";
            
            corriger += plop1;
           // System.Windows.MessageBox.Show(corriger);

            EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient client = new EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient();
            client.getCorrectionCompleted += new EventHandler<EtudiantsVDL.ServiceReference1.getCorrectionCompletedEventArgs>(correct_questions);
            client.getCorrectionAsync(lstQuestions[IndexQuestions]);
            questionsvalid++;
        }


        public void correct_questions(object sender, EtudiantsVDL.ServiceReference1.getCorrectionCompletedEventArgs e)
        {

            int i = 0;
            int z = 0;
            bool plop = false;

            List<int> temp = new List<int>();

            if (testFin)
            {

                if(ismultip){
                    while (i < checkRep.Count)
                    {

                        if ((e.Result[i][1].Equals("Y ") && checkRep[i].IsChecked == true))
                        {
                            plop = true;
                        }
                        else if (e.Result[i][1].Equals("N ") && checkRep[i].IsChecked == false)
                        {
                            plop = true;
                        }
                        else
                        {
                            plop = false;
                            i = checkRep.Count;
                        }

                        ++i;
                    }
                }
                else{
                    while (i < checkrd.Count)
                    {

                        if ((e.Result[i][1].Equals("Y ") && checkrd[i].IsChecked == true))
                        {
                            plop = true;
                        }
                        else if (e.Result[i][1].Equals("N ") && checkrd[i].IsChecked == false)
                        {
                            plop = true;
                        }
                        else
                        {
                            plop = false;
                            i = checkrd.Count;
                        }
                        ++i;
                    }
                }


                if(plop){
                    nbObt += pointCourant;
                }

               // System.Windows.MessageBox.Show(plop.ToString());

                lstQuestions.RemoveAt(IndexQuestions);

                //inscription du résultat nb points obtenue sur nombre de point total
                //Formule pour la correction du test
                // Math.Round((nbObt * (6 / nbTot)))
                //Math round represente l'arrondi du produits
                endTest();



            }
            else
            {
                if(ismultip){
                    while (i < checkRep.Count)
                    {

                        if ((e.Result[i][1].Equals("Y ") && checkRep[i].IsChecked == true))
                        {
                            plop = true;
                        }
                        else if (e.Result[i][1].Equals("N ") && checkRep[i].IsChecked == false)
                        {
                            plop = true;
                        }
                        else
                        {
                            plop = false;
                            i = checkRep.Count;
                        }

                        ++i;
                    }
                }
                else{

                    while (i < checkrd.Count)
                    {

                        if ((e.Result[i][1].Equals("Y ") && checkrd[i].IsChecked == true))
                        {
                            plop = true;
                        }
                        else if (e.Result[i][1].Equals("N ") && checkrd[i].IsChecked == false)
                        {
                            plop = true;
                        }
                        else
                        {
                            plop = false;
                            i = checkrd.Count;
                        }

                        ++i;
                    }

                }


               // System.Windows.MessageBox.Show(plop.ToString());

                if (plop)
                {
                    nbObt += pointCourant;
                }

                lstQuestions.RemoveAt(IndexQuestions);
   
                }

                int y = 0;


                while (y < lstQuestions.Count)
                {
                    // System.Windows.MessageBox.Show(y.ToString());
                    y++;
                }

                if (y == 1)
                {

                    testFin = true;

                    stckrep.Children.Clear();
                    EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient client = new EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient();
                    client.getQuestionCompleted += new EventHandler<EtudiantsVDL.ServiceReference1.getQuestionCompletedEventArgs>(build_questions);
                    client.getQuestionAsync((lstQuestions[y-1]));
                }
            }



        public bool endtest = false;
        public void endTest() {

            if (!endtest)
            {
                datefinest = DateTime.Now.ToString();
                resultats = Math.Round((nbObt * (6 / nbTot)));

                //note par defaut 
                if (resultats <= 0)
                {
                    resultats = 1;
                }

                chrono.Content = "";

                stackBtn.Children.Clear();
                stackQue.Children.Clear();
                stckrep.Children.Clear();
                atacklbTest.Children.Clear();

                //insertion du resultat
                // System.Windows.MessageBox.Show(resultats.ToString()+" "+ nbTot.ToString());

                EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient client = new EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient();
                client.insertResultCompleted += new EventHandler<EtudiantsVDL.ServiceReference1.insertResultCompletedEventArgs>(insert_resu);
                client.insertResultAsync(id_etudiant, id_test, corriger, datedebutest, datefinest, nbObt.ToString(), nbTot.ToString(), resultats.ToString());
                endtest = true;
       
            }
        }

        public void insert_resu(object sender,EtudiantsVDL.ServiceReference1.insertResultCompletedEventArgs e) {
            EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient client = new EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient();
            client.deloCompleted += new EventHandler<EtudiantsVDL.ServiceReference1.deloCompletedEventArgs>(closeApp);
            client.deloAsync(userVDLid);
            endtest = true;
        }



        }

 
}