﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Browser;


namespace EtudiantsVDL
{
    public partial class LogIN : ChildWindow
    {

        public string currentUser = string.Empty;
        string user = string.Empty;
        public Boolean authentifi = false;
        public int incorrectPWD = 0;
        string userloc = "LOCAL";
        public LogIN()
        {
            InitializeComponent();
            string UserAccount = App.UserID;
            string[] str = UserAccount.Split('\\');
            // System.Windows.MessageBox.Show(UserAccount);
            lbuserSOI.Content = str[1].ToUpper();
            lbAsset.Content = str[0].ToUpper();


            //Loaded += new RoutedEventHandler(OKButton_Click);

        }



        void read_user(object sender, EtudiantsVDL.ServiceReference1.getAuthentifCompletedEventArgs e)
        {
            if (e.Result.ToString().Equals("True"))
            {
                authentifi = true;
            }

            if (authentifi == false)
            {
                incorrectPWD++;
                lbCompte.Content = "Mot de pass au nom d'utilisateur incorrect !!" + "\n" + "Veuillez réesayer reste " + (4 - incorrectPWD).ToString() + " tentative";
            }

            if (incorrectPWD > 2)
            {
                EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient client = new EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient();
                client.sendMailAsync(App.UserID, currentUser);
            }
            if (incorrectPWD > 3)
            {
                HtmlPage.Window.Invoke("CloseWindow");
            }

            //condition de sortie
            if (authentifi == true)
            {



                // Ecriture d'un cookie 
                //DateTime expireDate = DateTime.Now + TimeSpan.FromDays(1);
                // string newCookie = lbuserSOI.Content.ToString() + "=" + currentUser + ",authentifié=true;expires=" + expireDate.ToString("R");
                //HtmlPage.Document.Cookies = "true";
                //HtmlPage.Document.SetProperty("cookie", newCookie);

                // User etu  = new User(currentUser,user);



                this.DialogResult = true;

            }
        }


        private void OKButton_Click(object sender, RoutedEventArgs e)
        {

            string usersoi = lbuserSOI.Content.ToString();
            string pwd2 = txtPWD.Password.ToString();
            user = txtUser.Text;
            currentUser = user;
            lbVDL.Content = currentUser;
            lbVDL.Content = user;
            txtPWD.Password = "";
            txtUser.Text = "";
            EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient client = new EtudiantsVDL.ServiceReference1.EtudiantsVDLServiceClient();
            client.getAuthentifCompleted += new EventHandler<EtudiantsVDL.ServiceReference1.getAuthentifCompletedEventArgs>(read_user);
            client.getAuthentifAsync(userloc, user, pwd2);


        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {


            txtPWD.Password = "";
            txtUser.Text = "";

        }


        //Overide la methode OnClosing accorde l'action fermé dans le contexte de la fenetre de Log IN
        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            txtPWD.Password = "";
            txtUser.Text = "";
            base.OnClosing(e);
            e.Cancel = true;
            //condition de sortie
            if (authentifi == true)
            {
                this.InitializeComponent();
                lbVDL.Content = this.currentUser;
                base.OnClosing(e);
                e.Cancel = false;

            }
        }


    }
}

